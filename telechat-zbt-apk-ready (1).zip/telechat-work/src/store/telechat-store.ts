import { create } from "zustand";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { signOut } from "@/lib/auth/client";
import {
  blockContactFn,
  bootstrapSession,
  createDirectChatFn,
  createGroupFn,
  createProfile,
  mutateChatFn,
  mutateMessageFn,
  pullInbox,
  saveProfile,
  searchPeople,
  sendServerMessage,
  terminateDeviceFn,
  type BootstrapPayload,
  type DeviceInput,
} from "@/lib/telechat/api";
import { playChime } from "@/lib/telechat/audio";
import { createId, ME_ID } from "@/lib/telechat/ids";
import { pickGroupReply, pickReply, replyDelay } from "@/lib/telechat/replies";
import {
  currentDeviceFingerprint,
  defaultProfile,
  hydrateSeedMedia,
  previewFrom,
  pruneDemoChats,
  rememberRealDevices,
  seedChatsAndMessages,
  seedContacts,
} from "@/lib/telechat/seed";
import { clearPersisted, readPersisted, writePersisted } from "@/lib/telechat/storage";
import type {
  AnimalId,
  AvatarSpec,
  Chat,
  ChatFilter,
  ComingSoonFeature,
  Contact,
  Message,
  PersistedState,
  Profile,
  ReactionId,
  Session,
  TabId,
  ThemeMode,
  UiState,
} from "@/lib/telechat/types";
import { isValidCode, isValidEmail, isValidUsername, normalizeUsername } from "@/lib/telechat/validators";

const emptyUi = (): UiState => ({
  tab: "chats",
  activeChatId: null,
  chatFilter: "all",
  showArchived: false,
  searchQuery: "",
  contactQuery: "",
  comingSoon: null,
  mediaViewer: null,
  forwardMessageId: null,
  selectedMessageId: null,
  chatInfoOpen: false,
  createMode: null,
  authEmail: "",
  authCode: "",
  authExpectedCode: "",
  authName: "",
  authUsername: "",
  authError: null,
  pinInput: "",
  pinError: null,
});

export interface TelechatStore {
  hydrated: boolean;
  theme: ThemeMode;
  session: Session | null;
  profile: Profile | null;
  contacts: Contact[];
  chats: Chat[];
  messages: Record<string, Message[]>;
  devices: PersistedState["devices"];
  drafts: Record<string, { chatId: string; text: string; replyToId: string | null; updatedAt: number }>;
  blockedIds: string[];
  wallpaper: string;
  ui: UiState;
  authStep: "email" | "code" | "username" | "welcome" | "app";
  hydrate: () => Promise<void>;
  persist: () => void;
  setTheme: (theme: ThemeMode) => void;
  setTab: (tab: TabId) => void;
  setAuthEmail: (value: string) => void;
  setAuthCode: (value: string) => void;
  setAuthName: (value: string) => void;
  setAuthUsername: (value: string) => void;
  requestCode: () => boolean;
  verifyCode: () => boolean;
  completeProfile: () => Promise<boolean>;
  finishWelcome: () => void;
  logout: () => void;
  openChat: (chatId: string | null) => void;
  setChatFilter: (filter: ChatFilter) => void;
  setShowArchived: (value: boolean) => void;
  setSearchQuery: (value: string) => void;
  setContactQuery: (value: string) => void;
  setComingSoon: (feature: ComingSoonFeature | null) => void;
  setCreateMode: (mode: UiState["createMode"]) => void;
  setChatInfoOpen: (open: boolean) => void;
  setDraft: (chatId: string, text: string, replyToId: string | null) => void;
  setReply: (chatId: string, messageId: string | null) => void;
  sendText: (chatId: string, text: string) => void;
  sendVoice: (chatId: string, mediaId: string, durationMs: number, peaks: number[]) => void;
  sendPhoto: (chatId: string, mediaId: string, width: number, height: number, caption?: string) => void;
  sendVideo: (
    chatId: string,
    mediaId: string,
    durationMs: number,
    width: number,
    height: number,
    caption?: string,
  ) => void;
  toggleReaction: (chatId: string, messageId: string, reaction: ReactionId) => void;
  deleteMessage: (chatId: string, messageId: string, forAll: boolean) => void;
  forwardMessage: (messageId: string, toChatId: string) => void;
  setForwardMessage: (messageId: string | null) => void;
  copyMessage: (messageId: string) => Promise<void>;
  createDirectChat: (contactId: string) => string;
  createGroup: (title: string, memberIds: string[], avatar?: AvatarSpec) => string;
  archiveChat: (chatId: string, archived: boolean) => void;
  muteChat: (chatId: string, muted: boolean) => void;
  pinChat: (chatId: string, pinned: boolean) => void;
  deleteChat: (chatId: string, forAll: boolean) => void;
  clearHistory: (chatId: string) => void;
  markRead: (chatId: string) => void;
  updateProfile: (patch: Partial<Profile>) => void;
  setAvatar: (avatar: AvatarSpec) => void;
  setAnimalAvatar: (animal: AnimalId) => void;
  setPin: (pin: string | null) => void;
  lock: () => void;
  unlock: (pin: string) => boolean;
  setPinInput: (value: string) => void;
  terminateDevice: (deviceId: string) => void;
  blockContact: (contactId: string, blocked: boolean) => void;
  addContactByUsername: (username: string) => Promise<Contact | null>;
  openMedia: (chatId: string, messageId: string | null) => void;
  tickPresence: () => void;
}

function snapshot(state: TelechatStore): PersistedState {
  return {
    version: 1,
    session: state.session,
    profile: state.profile,
    contacts: state.contacts,
    chats: state.chats,
    messages: state.messages,
    devices: state.devices,
    drafts: state.drafts,
    theme: state.theme,
    blockedIds: state.blockedIds,
    wallpaper: state.wallpaper,
  };
}

function applyTheme(theme: ThemeMode) {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("dark", theme === "dark");
  document.documentElement.classList.toggle("light", theme === "light");
  document.documentElement.style.colorScheme = theme;
}

function devicePayload(): DeviceInput {
  const device = currentDeviceFingerprint();
  return {
    id: device.id,
    name: device.name,
    platform: device.platform,
    location: device.location,
  };
}

function isUnauthorized(error: unknown): boolean {
  return error instanceof Error && error.message === "Unauthorized";
}

let persistTimer: ReturnType<typeof setTimeout> | null = null;
let replyTimers: ReturnType<typeof setTimeout>[] = [];

export const useTelechat = create<TelechatStore>((set, get) => {
  const persistSoon = () => {
    if (persistTimer) clearTimeout(persistTimer);
    persistTimer = setTimeout(() => get().persist(), 80);
  };

  const meId = () => get().profile?.id ?? ME_ID;

  const applyBootstrap = (payload: BootstrapPayload, step: TelechatStore["authStep"]) => {
    applyTheme(payload.theme);
    const session: Session = {
      email: payload.email || get().ui.authEmail,
      verifiedAt: Date.now(),
      onboarded: Boolean(payload.profile),
      locked: false,
    };
    set({
      hydrated: true,
      theme: payload.theme,
      session,
      profile: payload.profile,
      contacts: payload.contacts,
      chats: payload.chats,
      messages: payload.messages,
      devices: payload.devices,
      blockedIds: payload.blockedIds,
      wallpaper: payload.wallpaper,
      authStep: payload.profile ? step : "username",
    });
    persistSoon();
  };

  const syncFromServer = async () => {
    const payload = await bootstrapSession({ data: devicePayload() });
    if (payload.profile) {
      applyBootstrap(payload, "app");
      return payload;
    }
    set({
      hydrated: true,
      session: {
        email: payload.email || get().ui.authEmail,
        verifiedAt: Date.now(),
        onboarded: false,
        locked: false,
      },
      contacts: payload.contacts,
      devices: payload.devices,
      authStep: "username",
    });
    return payload;
  };

  const bumpChat = (chatId: string, preview: string, at: number, unreadInc = 0) => {
    set((state) => ({
      chats: state.chats.map((chat) =>
        chat.id === chatId
          ? {
              ...chat,
              lastMessagePreview: preview,
              lastMessageAt: at,
              unread: Math.max(0, chat.unread + unreadInc),
            }
          : chat,
      ),
    }));
  };

  const appendMessage = (message: Message, unreadInc = 0) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [message.chatId]: [...(state.messages[message.chatId] ?? []), message],
      },
    }));
    bumpChat(message.chatId, previewFrom(message), message.createdAt, unreadInc);
    persistSoon();
  };

  const scheduleReply = (chatId: string, text: string) => {
    const state = get();
    const chat = state.chats.find((c) => c.id === chatId);
    if (!chat) return;
    const others = chat.participantIds.filter((id) => id !== ME_ID && !state.blockedIds.includes(id));
    if (others.length === 0) return;
    const contact = state.contacts.find((c) => c.id === others[0]);
    const delay = replyDelay(contact?.online ?? false);

    set((s) => ({
      contacts: s.contacts.map((c) =>
        others.includes(c.id) ? { ...c, typing: true } : c,
      ),
    }));

    const timer = setTimeout(() => {
      const latest = get();
      const still = latest.chats.find((c) => c.id === chatId);
      if (!still || still.deletedForMe) return;
      set((s) => ({
        contacts: s.contacts.map((c) =>
          others.includes(c.id) ? { ...c, typing: false, online: true, lastSeen: Date.now() } : c,
        ),
      }));
      if (chat.type === "group") {
        const pick = pickGroupReply(latest.profile?.displayName ?? "вы", text);
        const speaker = others[pick.speakerOffset % others.length] ?? others[0];
        const speakerContact = latest.contacts.find((c) => c.id === speaker);
        appendMessage(
          makeMessage({
            chatId,
            senderId: speaker,
            text: pick.text,
          }),
          latest.ui.activeChatId === chatId ? 0 : 1,
        );
        if (latest.ui.activeChatId !== chatId) {
          playChime(latest.profile?.notificationSound ?? true);
        }
        void speakerContact;
      } else if (contact) {
        appendMessage(
          makeMessage({
            chatId,
            senderId: contact.id,
            text: pickReply(contact, text),
          }),
          latest.ui.activeChatId === chatId ? 0 : 1,
        );
        if (latest.ui.activeChatId !== chatId) {
          playChime(latest.profile?.notificationSound ?? true);
        }
      }
    }, delay);
    replyTimers.push(timer);
  };

  return {
    hydrated: false,
    theme: "dark",
    session: null,
    profile: null,
    contacts: [],
    chats: [],
    messages: {},
    devices: [],
    drafts: {},
    blockedIds: [],
    wallpaper: "ink",
    ui: emptyUi(),
    authStep: "email",

    async hydrate() {
      const saved = readPersisted();
      if (saved?.profile && saved.session?.onboarded) {
        applyTheme(saved.theme);
        const pruned = pruneDemoChats(saved.chats, saved.messages);
        set({
          hydrated: true,
          theme: saved.theme,
          session: saved.session,
          profile: saved.profile,
          contacts: saved.contacts,
          chats: pruned.chats,
          messages: pruned.messages,
          devices: rememberRealDevices(saved.devices),
          drafts: saved.drafts,
          blockedIds: saved.blockedIds,
          wallpaper: saved.wallpaper,
          authStep: saved.session.locked ? "app" : "app",
          ui: emptyUi(),
        });
        await hydrateSeedMedia(pruned.messages);
      } else {
        applyTheme("dark");
        set({ hydrated: true, authStep: "email", ui: emptyUi() });
      }
      try {
        await syncFromServer();
      } catch (error) {
        if (!isUnauthorized(error)) {
          console.warn("[telechat] bootstrap failed", error);
        }
      }
    },

    persist() {
      const state = get();
      if (!state.hydrated) return;
      writePersisted(snapshot(state));
    },

    setTheme(theme) {
      applyTheme(theme);
      set({ theme });
      persistSoon();
    },

    setTab(tab) {
      set((s) => ({ ui: { ...s.ui, tab, showArchived: false } }));
    },

    setAuthEmail(value) {
      set((s) => ({ ui: { ...s.ui, authEmail: value, authError: null } }));
    },
    setAuthCode(value) {
      set((s) => ({ ui: { ...s.ui, authCode: value.replace(/\D/g, "").slice(0, 4), authError: null } }));
    },
    setAuthName(value) {
      set((s) => ({ ui: { ...s.ui, authName: value, authError: null } }));
    },
    setAuthUsername(value) {
      set((s) => ({
        ui: { ...s.ui, authUsername: normalizeUsername(value), authError: null },
      }));
    },

    requestCode() {
      const email = get().ui.authEmail.trim();
      if (!isValidEmail(email)) {
        set((s) => ({ ui: { ...s.ui, authError: "Проверьте адрес почты" } }));
        return false;
      }
      const expected = String(1000 + Math.floor(Math.random() * 1000));
      set((s) => ({
        authStep: "code",
        ui: { ...s.ui, authCode: "", authExpectedCode: expected, authError: null },
      }));
      return true;
    },

    verifyCode() {
      const expected = get().ui.authExpectedCode;
      if (!isValidCode(get().ui.authCode, expected)) {
        set((s) => ({ ui: { ...s.ui, authError: "Неверный код" } }));
        return false;
      }
      const saved = readPersisted();
      const email = get().ui.authEmail.trim().toLowerCase();
      if (saved?.profile && saved.session && saved.profile.email.toLowerCase() === email) {
        applyTheme(saved.theme);
        const pruned = pruneDemoChats(saved.chats, saved.messages);
        set({
          session: { ...saved.session, verifiedAt: Date.now(), locked: false },
          profile: saved.profile,
          contacts: saved.contacts,
          chats: pruned.chats,
          messages: pruned.messages,
          devices: rememberRealDevices(saved.devices),
          drafts: saved.drafts,
          blockedIds: saved.blockedIds,
          wallpaper: saved.wallpaper,
          theme: saved.theme,
          authStep: "welcome",
        });
        persistSoon();
        void syncFromServer().catch((error) => {
          if (!isUnauthorized(error)) console.warn("[telechat] bootstrap failed", error);
        });
        return true;
      }
      set({ authStep: "username" });
      void syncFromServer()
        .then((payload) => {
          if (payload.profile) set({ authStep: "welcome" });
        })
        .catch((error) => {
          if (!isUnauthorized(error)) console.warn("[telechat] bootstrap failed", error);
        });
      return true;
    },

    async completeProfile() {
      const { authName, authUsername } = get().ui;
      if (authName.trim().length < 2) {
        set((s) => ({ ui: { ...s.ui, authError: "Имя не может быть пустым" } }));
        return false;
      }
      if (!isValidUsername(authUsername)) {
        set((s) => ({
          ui: { ...s.ui, authError: "Юзернейм: 5–32 символа, латиница, цифры и _" },
        }));
        return false;
      }
      const handle = normalizeUsername(authUsername);
      if (handle === "telechat") {
        set((s) => ({ ui: { ...s.ui, authError: "Этот юзернейм уже занят" } }));
        return false;
      }
      try {
        const payload = await createProfile({
          data: {
            displayName: authName.trim(),
            username: handle,
            device: devicePayload(),
          },
        });
        if (payload.profile) {
          applyBootstrap(payload, "welcome");
          return true;
        }
      } catch (error) {
        if (error instanceof Error && error.message === "username-taken") {
          set((s) => ({ ui: { ...s.ui, authError: "Этот юзернейм уже занят" } }));
          return false;
        }
        if (error instanceof Error && error.message === "invalid-username") {
          set((s) => ({
            ui: { ...s.ui, authError: "Юзернейм: 5–32 символа, латиница, цифры и _" },
          }));
          return false;
        }
        if (!isUnauthorized(error)) {
          console.warn("[telechat] createProfile failed", error);
        }
      }
      const taken = get().contacts.some((c) => c.username === handle);
      if (taken) {
        set((s) => ({ ui: { ...s.ui, authError: "Этот юзернейм уже занят" } }));
        return false;
      }
      const contacts = seedContacts().filter((c) => c.isOfficial);
      const seeded = seedChatsAndMessages(contacts);
      const { chats, messages } = pruneDemoChats(seeded.chats, seeded.messages);
      void hydrateSeedMedia(messages);
      const profile = defaultProfile(get().ui.authEmail.trim(), authName.trim(), handle);
      const session: Session = {
        email: profile.email,
        verifiedAt: Date.now(),
        onboarded: true,
        locked: false,
      };
      set({
        profile,
        session,
        contacts,
        chats,
        messages,
        devices: rememberRealDevices([]),
        drafts: {},
        blockedIds: [],
        authStep: "welcome",
      });
      persistSoon();
      return true;
    },

    finishWelcome() {
      set((s) => ({
        authStep: "app",
        session: s.session ? { ...s.session, onboarded: true } : s.session,
      }));
      persistSoon();
    },

    logout() {
      replyTimers.forEach(clearTimeout);
      replyTimers = [];
      clearPersisted();
      if (!hasGateSessionMarker()) {
        void signOut();
      }
      applyTheme("dark");
      set({
        session: null,
        profile: null,
        contacts: [],
        chats: [],
        messages: {},
        devices: [],
        drafts: {},
        blockedIds: [],
        wallpaper: "ink",
        theme: "dark",
        authStep: "email",
        ui: emptyUi(),
      });
    },

    openChat(chatId) {
      set((s) => ({
        ui: {
          ...s.ui,
          activeChatId: chatId,
          selectedMessageId: null,
          chatInfoOpen: false,
          showArchived: chatId ? s.ui.showArchived : s.ui.showArchived,
        },
      }));
      if (chatId) get().markRead(chatId);
    },

    setChatFilter(filter) {
      set((s) => ({ ui: { ...s.ui, chatFilter: filter } }));
    },
    setShowArchived(value) {
      set((s) => ({ ui: { ...s.ui, showArchived: value, activeChatId: null } }));
    },
    setSearchQuery(value) {
      set((s) => ({ ui: { ...s.ui, searchQuery: value } }));
    },
    setContactQuery(value) {
      set((s) => ({ ui: { ...s.ui, contactQuery: value } }));
    },
    setComingSoon(feature) {
      set((s) => ({ ui: { ...s.ui, comingSoon: feature } }));
    },
    setCreateMode(mode) {
      set((s) => ({ ui: { ...s.ui, createMode: mode } }));
    },
    setChatInfoOpen(open) {
      set((s) => ({ ui: { ...s.ui, chatInfoOpen: open } }));
    },

    setDraft(chatId, text, replyToId) {
      set((s) => ({
        drafts: {
          ...s.drafts,
          [chatId]: { chatId, text, replyToId, updatedAt: Date.now() },
        },
      }));
      persistSoon();
    },

    setReply(chatId, messageId) {
      const current = get().drafts[chatId];
      get().setDraft(chatId, current?.text ?? "", messageId);
    },

    sendText(chatId, text) {
      const clean = text.trim();
      if (!clean) return;
      const chat = get().chats.find((c) => c.id === chatId);
      if (!chat || get().blockedIds.some((id) => chat.participantIds.includes(id) && chat.type === "direct")) {
        return;
      }
      get().setDraft(chatId, "", null);
      void (async () => {
        try {
          const message = await sendServerMessage({
            data: { chatId, type: "text", text: clean },
          });
          appendMessage(message);
        } catch {
          appendMessage(makeMessage({ chatId, senderId: meId(), text: clean }));
          scheduleReply(chatId, clean);
        }
      })();
    },

    sendVoice(chatId, mediaId, durationMs, peaks) {
      appendMessage(
        makeMessage({
          chatId,
          senderId: ME_ID,
          type: "voice",
          voice: { mediaId, durationMs, peaks },
        }),
      );
      scheduleReply(chatId, "голос");
    },

    sendPhoto(chatId, mediaId, width, height, caption) {
      appendMessage(
        makeMessage({
          chatId,
          senderId: ME_ID,
          type: "photo",
          text: caption ?? "",
          photo: { mediaId, width, height, caption },
        }),
      );
      scheduleReply(chatId, caption || "фото");
    },

    sendVideo(chatId, mediaId, durationMs, width, height, caption) {
      appendMessage(
        makeMessage({
          chatId,
          senderId: ME_ID,
          type: "video",
          text: caption ?? "",
          video: { mediaId, durationMs, width, height, caption },
        }),
      );
      scheduleReply(chatId, caption || "видео");
    },

    toggleReaction(chatId, messageId, reaction) {
      set((state) => ({
        messages: {
          ...state.messages,
          [chatId]: (state.messages[chatId] ?? []).map((m) => {
            if (m.id !== messageId) return m;
            const current = new Set(m.reactions[reaction] ?? []);
            if (current.has(ME_ID)) current.delete(ME_ID);
            else current.add(ME_ID);
            return {
              ...m,
              reactions: {
                ...m.reactions,
                [reaction]: Array.from(current),
              },
            };
          }),
        },
      }));
      persistSoon();
    },

    deleteMessage(chatId, messageId, forAll) {
      set((state) => ({
        messages: {
          ...state.messages,
          [chatId]: (state.messages[chatId] ?? []).map((m) => {
            if (m.id !== messageId) return m;
            if (forAll) {
              return {
                ...m,
                deletedForAll: true,
                text: "",
                voice: undefined,
                photo: undefined,
                video: undefined,
              };
            }
            return { ...m, deletedForMe: true };
          }),
        },
      }));
      const list = (get().messages[chatId] ?? []).filter((m) => !m.deletedForMe);
      const last = [...list].reverse().find((m) => !m.deletedForAll);
      bumpChat(chatId, last ? previewFrom(last) : "", last?.createdAt ?? Date.now());
      persistSoon();
    },

    setForwardMessage(messageId) {
      set((s) => ({ ui: { ...s.ui, forwardMessageId: messageId } }));
    },

    forwardMessage(messageId, toChatId) {
      let found: Message | undefined;
      for (const list of Object.values(get().messages)) {
        found = list.find((m) => m.id === messageId);
        if (found) break;
      }
      if (!found || found.deletedForAll) return;
      const from =
        found.senderId === ME_ID
          ? get().profile
          : get().contacts.find((c) => c.id === found?.senderId);
      appendMessage(
        makeMessage({
          chatId: toChatId,
          senderId: ME_ID,
          type: found.type,
          text: found.text,
          voice: found.voice,
          photo: found.photo,
          video: found.video,
          forwarded: {
            fromId: found.senderId,
            fromName: from?.displayName ?? "TeleChat",
          },
        }),
      );
      set((s) => ({ ui: { ...s.ui, forwardMessageId: null } }));
      scheduleReply(toChatId, found.text || "сообщение");
    },

    async copyMessage(messageId) {
      let found: Message | undefined;
      for (const list of Object.values(get().messages)) {
        found = list.find((m) => m.id === messageId);
        if (found) break;
      }
      if (!found?.text) return;
      try {
        await navigator.clipboard.writeText(found.text);
      } catch {
        /* ignore */
      }
    },

    createDirectChat(contactId) {
      const existing = get().chats.find(
        (c) => c.type === "direct" && c.participantIds.includes(contactId) && !c.deletedForMe,
      );
      if (existing) {
        get().openChat(existing.id);
        set((s) => ({ ui: { ...s.ui, tab: "chats", createMode: null } }));
        return existing.id;
      }
      const contact = get().contacts.find((c) => c.id === contactId);
      if (!contact) return "";
      const chat: Chat = {
        id: createId("chat"),
        type: "direct",
        title: contact.displayName,
        avatar: contact.avatar,
        participantIds: [ME_ID, contactId],
        lastMessagePreview: "",
        lastMessageAt: Date.now(),
        unread: 0,
        muted: false,
        archived: false,
        pinned: false,
        pinnedMessageId: null,
        createdAt: Date.now(),
        createdBy: ME_ID,
        deletedForMe: false,
      };
      set((s) => ({
        chats: [chat, ...s.chats],
        messages: { ...s.messages, [chat.id]: [] },
        ui: { ...s.ui, tab: "chats", activeChatId: chat.id, createMode: null },
      }));
      persistSoon();
      return chat.id;
    },

    createGroup(title, memberIds, avatar) {
      const name = title.trim();
      if (!name) return "";
      const chat: Chat = {
        id: createId("grp"),
        type: "group",
        title: name,
        avatar: avatar ?? {
          kind: "gradient",
          hue: name.length * 17,
          initials: name.slice(0, 2).toUpperCase(),
        },
        participantIds: [ME_ID, ...memberIds.filter((id) => id !== ME_ID)],
        lastMessagePreview: "Группа создана",
        lastMessageAt: Date.now(),
        unread: 0,
        muted: false,
        archived: false,
        pinned: false,
        pinnedMessageId: null,
        createdAt: Date.now(),
        createdBy: ME_ID,
        deletedForMe: false,
      };
      const system = makeMessage({
        chatId: chat.id,
        senderId: ME_ID,
        type: "system",
        text: `Вы создали группу «${name}»`,
      });
      set((s) => ({
        chats: [chat, ...s.chats],
        messages: { ...s.messages, [chat.id]: [system] },
        ui: { ...s.ui, tab: "chats", activeChatId: chat.id, createMode: null },
      }));
      persistSoon();
      return chat.id;
    },

    archiveChat(chatId, archived) {
      set((s) => ({
        chats: s.chats.map((c) => (c.id === chatId ? { ...c, archived } : c)),
        ui: {
          ...s.ui,
          activeChatId: s.ui.activeChatId === chatId ? null : s.ui.activeChatId,
        },
      }));
      persistSoon();
    },

    muteChat(chatId, muted) {
      set((s) => ({
        chats: s.chats.map((c) => (c.id === chatId ? { ...c, muted } : c)),
      }));
      persistSoon();
    },

    pinChat(chatId, pinned) {
      set((s) => ({
        chats: s.chats.map((c) => (c.id === chatId ? { ...c, pinned } : c)),
      }));
      persistSoon();
    },

    deleteChat(chatId, forAll) {
      if (forAll) {
        set((s) => ({
          chats: s.chats.filter((c) => c.id !== chatId),
          messages: Object.fromEntries(
            Object.entries(s.messages).filter(([id]) => id !== chatId),
          ),
          ui: {
            ...s.ui,
            activeChatId: s.ui.activeChatId === chatId ? null : s.ui.activeChatId,
          },
        }));
      } else {
        set((s) => ({
          chats: s.chats.map((c) =>
            c.id === chatId ? { ...c, deletedForMe: true, unread: 0 } : c,
          ),
          ui: {
            ...s.ui,
            activeChatId: s.ui.activeChatId === chatId ? null : s.ui.activeChatId,
          },
        }));
      }
      persistSoon();
    },

    clearHistory(chatId) {
      const system = makeMessage({
        chatId,
        senderId: ME_ID,
        type: "system",
        text: "История очищена",
      });
      set((s) => ({
        messages: { ...s.messages, [chatId]: [system] },
        chats: s.chats.map((c) =>
          c.id === chatId
            ? { ...c, lastMessagePreview: "История очищена", lastMessageAt: Date.now(), unread: 0 }
            : c,
        ),
      }));
      persistSoon();
    },

    markRead(chatId) {
      set((s) => ({
        chats: s.chats.map((c) => (c.id === chatId ? { ...c, unread: 0 } : c)),
        messages: {
          ...s.messages,
          [chatId]: (s.messages[chatId] ?? []).map((m) =>
            m.senderId !== ME_ID ? { ...m, status: "read" } : m,
          ),
        },
      }));
      persistSoon();
    },

    updateProfile(patch) {
      set((s) => ({
        profile: s.profile ? { ...s.profile, ...patch } : s.profile,
      }));
      persistSoon();
    },

    setAvatar(avatar) {
      get().updateProfile({ avatar });
    },

    setAnimalAvatar(animal) {
      get().updateProfile({ avatar: { kind: "animal", animal } });
    },

    setPin(pin) {
      get().updateProfile({ pin });
    },

    lock() {
      const pin = get().profile?.pin;
      if (!pin) return;
      set((s) => ({
        session: s.session ? { ...s.session, locked: true } : s.session,
        ui: { ...s.ui, pinInput: "", pinError: null },
      }));
      persistSoon();
    },

    unlock(pin) {
      if (pin !== get().profile?.pin) {
        set((s) => ({ ui: { ...s.ui, pinError: "Неверный код" } }));
        return false;
      }
      set((s) => ({
        session: s.session ? { ...s.session, locked: false } : s.session,
        ui: { ...s.ui, pinInput: "", pinError: null },
      }));
      persistSoon();
      return true;
    },

    setPinInput(value) {
      set((s) => ({
        ui: { ...s.ui, pinInput: value.replace(/\D/g, "").slice(0, 6), pinError: null },
      }));
    },

    terminateDevice(deviceId) {
      set((s) => ({
        devices: s.devices.filter((d) => d.id !== deviceId || d.current),
      }));
      persistSoon();
    },

    blockContact(contactId, blocked) {
      set((s) => ({
        blockedIds: blocked
          ? Array.from(new Set([...s.blockedIds, contactId]))
          : s.blockedIds.filter((id) => id !== contactId),
        contacts: s.contacts.map((c) =>
          c.id === contactId ? { ...c, isBlocked: blocked } : c,
        ),
      }));
      persistSoon();
    },

    addContactByUsername(username) {
      const handle = normalizeUsername(username);
      const found = get().contacts.find((c) => c.username === handle);
      return found ?? null;
    },

    openMedia(chatId, messageId) {
      set((s) => ({
        ui: {
          ...s.ui,
          mediaViewer: messageId ? { chatId, messageId } : null,
        },
      }));
    },

    tickPresence() {
      set((s) => ({
        contacts: s.contacts.map((c) => {
          if (c.isOfficial) return { ...c, online: true, lastSeen: Date.now() };
          if (c.typing) return c;
          const wander = Math.sin(Date.now() / 70000 + c.id.length) > 0.25;
          return {
            ...c,
            online: wander && !c.isBlocked,
            lastSeen: wander ? Date.now() : c.lastSeen,
          };
        }),
        devices: s.devices.map((d) =>
          d.current ? { ...d, lastActive: Date.now() } : d,
        ),
      }));
    },
  };
});

function makeMessage(partial: {
  chatId: string;
  senderId: string;
  text?: string;
  type?: Message["type"];
  voice?: Message["voice"];
  photo?: Message["photo"];
  video?: Message["video"];
  forwarded?: Message["forwarded"];
}): Message {
  return {
    id: createId("msg"),
    chatId: partial.chatId,
    senderId: partial.senderId,
    type: partial.type ?? "text",
    text: partial.text ?? "",
    createdAt: Date.now(),
    editedAt: null,
    status: partial.senderId === ME_ID ? "sent" : "delivered",
    replyToId: null,
    forwarded: partial.forwarded ?? null,
    reactions: {},
    deletedForMe: false,
    deletedForAll: false,
    voice: partial.voice,
    photo: partial.photo,
    video: partial.video,
  };
}

export function selectVisibleChats(state: TelechatStore) {
  const q = state.ui.searchQuery.trim().toLowerCase();
  return state.chats
    .filter((c) => !c.deletedForMe)
    .filter((c) => (state.ui.showArchived ? c.archived : !c.archived))
    .filter((c) => {
      if (state.ui.chatFilter === "unread") return c.unread > 0;
      if (state.ui.chatFilter === "groups") return c.type === "group";
      if (state.ui.chatFilter === "muted") return c.muted;
      return true;
    })
    .filter((c) => {
      if (!q) return true;
      if (c.title.toLowerCase().includes(q)) return true;
      if (c.lastMessagePreview.toLowerCase().includes(q)) return true;
      return c.participantIds.some((id) => {
        const contact = state.contacts.find((x) => x.id === id);
        return (
          contact?.displayName.toLowerCase().includes(q) ||
          contact?.username.toLowerCase().includes(q)
        );
      });
    })
    .sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return b.lastMessageAt - a.lastMessageAt;
    });
}

export function selectContacts(state: TelechatStore) {
  const q = state.ui.contactQuery.trim().toLowerCase().replace(/^@/, "");
  return state.contacts
    .filter((c) => !c.isBlocked)
    .filter((c) => {
      if (!q) return true;
      return (
        c.displayName.toLowerCase().includes(q) ||
        c.username.toLowerCase().includes(q) ||
        c.bio.toLowerCase().includes(q)
      );
    })
    .sort((a, b) => Number(b.online) - Number(a.online) || a.displayName.localeCompare(b.displayName, "ru"));
}

export function findMessage(state: TelechatStore, messageId: string | null): Message | undefined {
  if (!messageId) return undefined;
  for (const list of Object.values(state.messages)) {
    const found = list.find((m) => m.id === messageId);
    if (found) return found;
  }
  return undefined;
}

export function chatPeer(state: TelechatStore, chat: Chat): Contact | Profile | undefined {
  if (chat.type === "group") return undefined;
  const id = chat.participantIds.find((x) => x !== ME_ID);
  if (id === ME_ID) return state.profile ?? undefined;
  return state.contacts.find((c) => c.id === id);
}
