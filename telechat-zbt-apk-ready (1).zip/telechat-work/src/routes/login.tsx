import { createFileRoute } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { TelechatMark } from "@/components/telechat/logo";
import { t } from "@/lib/telechat/constants";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <main className="app-wallpaper-ink grid min-h-dvh place-items-center px-6">
      <div className="w-full max-w-sm">
        <div className="rise-in flex flex-col items-center text-center">
          <TelechatMark className="size-20" />
          <h1 className="mt-6 text-[32px] font-semibold tracking-tight">{t.appName}</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Войдите, чтобы сообщения и устройства хранились на сервере. Фейковых сессий нет — только реальные входы.
          </p>
        </div>
        <div className="rise-in rise-in-2 mt-8 flex flex-col gap-3">
          {authEnabled ? (
            GROK_PROVIDERS.map((provider) => (
              <button
                key={provider.providerId}
                type="button"
                onClick={() => signIn(provider.providerId, { callbackURL: "/" })}
                className="tap h-12 rounded-2xl bg-accent text-[15px] font-semibold text-accent-fg"
              >
                Продолжить с {provider.label}
              </button>
            ))
          ) : (
            <p className="text-center text-sm text-muted">Вход выключен.</p>
          )}
        </div>
      </div>
    </main>
  );
}
