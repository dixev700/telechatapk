export type ThemeMode = "dark" | "light";

export type AnimalId =
  | "fox"
  | "cat"
  | "owl"
  | "bear"
  | "panda"
  | "wolf"
  | "rabbit"
  | "whale"
  | "bird"
  | "tiger"
  | "frog"
  | "dog"
  | "deer"
  | "penguin"
  | "koala"
  | "otter";

export type AvatarSpec =
  | { kind: "gradient"; hue: number; initials: string }
  | { kind: "animal"; animal: AnimalId }
  | { kind: "image"; src: string };

export type ReactionId = "heart" | "like" | "fire" | "laugh" | "wow" | "sad";

export type MessageType = "text" | "voice" | "photo" | "video" | "system";

export type MessageStatus = "sending" | "sent" | "delivered" | "read";

export type ChatType = "direct" | "group";

export type TabId = "chats" | "contacts" | "settings" | "profile";

export type AuthStep = "email" | "code" | "username" | "welcome";

export type ChatFilter = "all" | "unread" | "groups" | "muted";

export interface Profile {
  id: string;
  email: string;
  displayName: string;
  username: string;
  avatar: AvatarSpec;
  bio: string;
  pin: string | null;
  createdAt: number;
  lastSeenPrivacy: "everyone" | "contacts" | "nobody";
  readReceipts: boolean;
  notificationSound: boolean;
  saveToGallery: boolean;
  fontSize: "small" | "medium" | "large";
}

export interface Contact {
  id: string;
  displayName: string;
  username: string;
  avatar: AvatarSpec;
  bio: string;
  lastSeen: number;
  online: boolean;
  typing: boolean;
  isOfficial?: boolean;
  isMuted?: boolean;
  isBlocked?: boolean;
  phone?: string;
  city?: string;
}

export interface Chat {
  id: string;
  type: ChatType;
  title: string;
  avatar: AvatarSpec;
  participantIds: string[];
  lastMessagePreview: string;
  lastMessageAt: number;
  unread: number;
  muted: boolean;
  archived: boolean;
  pinned: boolean;
  pinnedMessageId: string | null;
  createdAt: number;
  createdBy: string;
  deletedForMe: boolean;
  description?: string;
}

export interface VoicePayload {
  mediaId: string;
  durationMs: number;
  peaks: number[];
}

export interface PhotoPayload {
  mediaId: string;
  width: number;
  height: number;
  caption?: string;
}

export interface VideoPayload {
  mediaId: string;
  durationMs: number;
  width: number;
  height: number;
  caption?: string;
}

export interface ForwardMeta {
  fromId: string;
  fromName: string;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  type: MessageType;
  text: string;
  createdAt: number;
  editedAt: number | null;
  status: MessageStatus;
  replyToId: string | null;
  forwarded: ForwardMeta | null;
  reactions: Partial<Record<ReactionId, string[]>>;
  deletedForMe: boolean;
  deletedForAll: boolean;
  voice?: VoicePayload;
  photo?: PhotoPayload;
  video?: VideoPayload;
}

export interface Device {
  id: string;
  name: string;
  platform: "web" | "ios" | "android" | "desktop";
  location: string;
  lastActive: number;
  current: boolean;
  ip: string;
}

export interface Draft {
  chatId: string;
  text: string;
  replyToId: string | null;
  updatedAt: number;
}

export interface Session {
  email: string;
  verifiedAt: number;
  onboarded: boolean;
  locked: boolean;
}

export interface PersistedState {
  version: 1;
  session: Session | null;
  profile: Profile | null;
  contacts: Contact[];
  chats: Chat[];
  messages: Record<string, Message[]>;
  devices: Device[];
  drafts: Record<string, Draft>;
  theme: ThemeMode;
  blockedIds: string[];
  wallpaper: string;
}

export interface MediaRecord {
  id: string;
  mime: string;
  createdAt: number;
  dataUrl: string;
}

export type ComingSoonFeature =
  | "calls"
  | "stories"
  | "channels"
  | "secret"
  | "payments"
  | "bots"
  | "stickers"
  | "export"
  | "folders"
  | "live-location"
  | "polls"
  | "translation";

export interface ComposerState {
  text: string;
  replyToId: string | null;
  recording: boolean;
  recordStartedAt: number | null;
}

export interface UiState {
  tab: TabId;
  activeChatId: string | null;
  chatFilter: ChatFilter;
  showArchived: boolean;
  searchQuery: string;
  contactQuery: string;
  comingSoon: ComingSoonFeature | null;
  mediaViewer: { chatId: string; messageId: string } | null;
  forwardMessageId: string | null;
  selectedMessageId: string | null;
  chatInfoOpen: boolean;
  createMode: null | "direct" | "group";
  authEmail: string;
  authCode: string;
  authExpectedCode: string;
  authName: string;
  authUsername: string;
  authError: string | null;
  pinInput: string;
  pinError: string | null;
}
