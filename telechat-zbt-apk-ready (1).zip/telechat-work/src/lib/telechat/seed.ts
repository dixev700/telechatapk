import { makePatternPhoto } from "./media";
import { fakePeaks } from "./audio";
import { putMedia } from "./storage";
import { createId, hueFromString, initialsFromName, ME_ID, TEAM_ID } from "./ids";
import type {
  AnimalId,
  AvatarSpec,
  Chat,
  Contact,
  Device,
  Message,
  Profile,
} from "./types";

const HOUR = 3_600_000;
const MIN = 60_000;

function ago(hours: number, minutes = 0): number {
  return Date.now() - hours * HOUR - minutes * MIN;
}

function gradient(name: string): AvatarSpec {
  return {
    kind: "gradient",
    hue: hueFromString(name),
    initials: initialsFromName(name),
  };
}

function animal(id: AnimalId): AvatarSpec {
  return { kind: "animal", animal: id };
}

export function defaultProfile(email: string, displayName: string, username: string): Profile {
  return {
    id: ME_ID,
    email,
    displayName,
    username,
    avatar: gradient(displayName),
    bio: "Привет, я в TeleChat.",
    pin: null,
    createdAt: Date.now(),
    lastSeenPrivacy: "everyone",
    readReceipts: true,
    notificationSound: true,
    saveToGallery: false,
    fontSize: "medium",
  };
}

export function seedContacts(): Contact[] {
  return [
    {
      id: TEAM_ID,
      displayName: "TeleChat",
      username: "telechat",
      avatar: { kind: "gradient", hue: 199, initials: "TC" },
      bio: "Официальный аккаунт сервиса. Подсказки, новости и поддержка.",
      lastSeen: Date.now(),
      online: true,
      typing: false,
      isOfficial: true,
      city: "TeleChat Cloud",
    },
    {
      id: "user_anna",
      displayName: "Анна Волкова",
      username: "anna_volkova",
      avatar: animal("fox"),
      bio: "Дизайн · продукт · Figma",
      lastSeen: ago(0, 4),
      online: true,
      typing: false,
      city: "Москва",
      phone: "+7 900 111-22-33",
    },
    {
      id: "user_dmitry",
      displayName: "Дмитрий Орлов",
      username: "orlovd",
      avatar: animal("wolf"),
      bio: "Снимаю город и пью слишком много кофе.",
      lastSeen: ago(0, 18),
      online: true,
      typing: false,
      city: "Санкт-Петербург",
    },
    {
      id: "user_mom",
      displayName: "Мама",
      username: "marina_k",
      avatar: animal("cat"),
      bio: "Звони, не пиши.",
      lastSeen: ago(2, 10),
      online: false,
      typing: false,
      city: "Казань",
    },
    {
      id: "user_elena",
      displayName: "Елена Соколова",
      username: "sokolova",
      avatar: gradient("Елена Соколова"),
      bio: "Проджект. Дедлайны люблю больше, чем сюрпризы.",
      lastSeen: ago(0, 40),
      online: false,
      typing: false,
      city: "Москва",
    },
    {
      id: "user_max",
      displayName: "Максим Петров",
      username: "maxlift",
      avatar: animal("bear"),
      bio: "Сила. Режим. Без оправданий.",
      lastSeen: ago(1, 5),
      online: false,
      typing: false,
      city: "Екатеринбург",
    },
    {
      id: "user_sofia",
      displayName: "София Иванова",
      username: "sofi_i",
      avatar: animal("rabbit"),
      bio: "Аспирантура и бесконечные слайды.",
      lastSeen: ago(0, 12),
      online: true,
      typing: false,
      city: "Новосибирск",
    },
    {
      id: "user_alexey",
      displayName: "Алексей Новиков",
      username: "novikov",
      avatar: animal("owl"),
      bio: "Сосед справа, если что.",
      lastSeen: ago(5, 0),
      online: false,
      typing: false,
      city: "Москва",
    },
    {
      id: "user_irina",
      displayName: "Ирина",
      username: "irina_s",
      avatar: animal("otter"),
      bio: "Сестра. Возвращаю зарядки.",
      lastSeen: ago(3, 20),
      online: false,
      typing: false,
      city: "Казань",
    },
    {
      id: "user_nikita",
      displayName: "Никита Громов",
      username: "gromov",
      avatar: animal("tiger"),
      bio: "Катки, патчи, мемы.",
      lastSeen: ago(0, 7),
      online: true,
      typing: false,
      city: "Краснодар",
    },
    {
      id: "user_kira",
      displayName: "Кира Лебедева",
      username: "lebedeva",
      avatar: animal("bird"),
      bio: "Редактор. Правлю чужие запятые.",
      lastSeen: ago(8, 0),
      online: false,
      typing: false,
      city: "Москва",
    },
    {
      id: "user_timur",
      displayName: "Тимур Сафин",
      username: "safin",
      avatar: animal("whale"),
      bio: "Бэкенд, деплой, спокойствие.",
      lastSeen: ago(6, 30),
      online: false,
      typing: false,
      city: "Казань",
    },
    {
      id: "user_olga",
      displayName: "Ольга Белова",
      username: "belova",
      avatar: gradient("Ольга Белова"),
      bio: "Фотограф выходного дня.",
      lastSeen: ago(26, 0),
      online: false,
      typing: false,
      city: "Сочи",
    },
  ];
}

export const DEMO_CHAT_IDS = [
  "chat_anna",
  "chat_dmitry",
  "chat_mom",
  "chat_elena",
  "chat_max",
  "chat_sofia",
  "chat_nikita",
  "chat_irina",
  "chat_alexey",
  "chat_kira",
  "chat_project",
  "chat_family",
  "chat_hike",
];

type Line = {
  from: "me" | string;
  text?: string;
  hours: number;
  minutes?: number;
  kind?: "text" | "voice" | "photo" | "system";
  duration?: number;
  photoSeed?: string;
  reactions?: Message["reactions"];
};

function buildMessages(chatId: string, lines: Line[]): Message[] {
  return lines.map((line, index) => {
    const createdAt = ago(line.hours, line.minutes ?? 0);
    const senderId = line.from === "me" ? ME_ID : line.from;
    const type = line.kind ?? "text";
    const message: Message = {
      id: `${chatId}_m${index + 1}`,
      chatId,
      senderId,
      type,
      text: line.text ?? "",
      createdAt,
      editedAt: null,
      status: senderId === ME_ID ? "read" : "delivered",
      replyToId: null,
      forwarded: null,
      reactions: line.reactions ?? {},
      deletedForMe: false,
      deletedForAll: false,
    };
    if (type === "voice") {
      message.voice = {
        mediaId: `${chatId}_voice_${index}`,
        durationMs: (line.duration ?? 8) * 1000,
        peaks: fakePeaks(index + chatId.length, 32),
      };
      message.text = "";
    }
    if (type === "photo") {
      message.photo = {
        mediaId: `${chatId}_photo_${index}`,
        width: 720,
        height: 480,
        caption: line.text,
      };
    }
    return message;
  });
}

export function seedChatsAndMessages(contacts: Contact[]): {
  chats: Chat[];
  messages: Record<string, Message[]>;
} {
  const byId = Object.fromEntries(contacts.map((c) => [c.id, c]));
  const messages: Record<string, Message[]> = {};

  const scripts: Array<{
    id: string;
    type: "direct" | "group";
    title?: string;
    participants: string[];
    avatar?: AvatarSpec;
    pinned?: boolean;
    muted?: boolean;
    archived?: boolean;
    unread?: number;
    description?: string;
    lines: Line[];
  }> = [
    {
      id: "chat_team",
      type: "direct",
      participants: [ME_ID, TEAM_ID],
      pinned: true,
      unread: 1,
      lines: [
        {
          from: TEAM_ID,
          hours: 48,
          text: "Это TeleChat. Здесь ваши чаты, группы и медиа — всё хранится на устройстве.",
        },
        {
          from: TEAM_ID,
          hours: 48,
          minutes: -2,
          text: "Подсказка: зажмите сообщение, чтобы поставить реакцию, переслать или удалить.",
        },
        {
          from: "me",
          hours: 47,
          text: "Понял, спасибо.",
        },
        {
          from: TEAM_ID,
          hours: 0,
          minutes: 8,
          text: "Добро пожаловать в TeleChat! Пишите сюда, если что-то сломается.",
        },
      ],
    },
  ];

  const chats: Chat[] = scripts.map((script) => {
    const list = buildMessages(script.id, script.lines);
    messages[script.id] = list;
    const last = list[list.length - 1];
    const other = script.participants.find((id) => id !== ME_ID);
    const contact = other ? byId[other] : undefined;
    const title =
      script.type === "group"
        ? script.title ?? "Группа"
        : contact?.displayName ?? "Чат";
    const avatar =
      script.avatar ??
      contact?.avatar ??
      gradient(title);
    return {
      id: script.id,
      type: script.type,
      title,
      avatar,
      participantIds: script.participants,
      lastMessagePreview: previewFrom(last),
      lastMessageAt: last?.createdAt ?? Date.now(),
      unread: script.unread ?? 0,
      muted: script.muted ?? false,
      archived: script.archived ?? false,
      pinned: script.pinned ?? false,
      pinnedMessageId: null,
      createdAt: list[0]?.createdAt ?? Date.now(),
      createdBy: ME_ID,
      deletedForMe: false,
      description: script.description,
    };
  });

  return { chats, messages };
}

function previewFrom(message: Message | undefined): string {
  if (!message || message.deletedForAll) return "";
  if (message.type === "voice") return "Голосовое сообщение";
  if (message.type === "photo") return message.photo?.caption || "Фото";
  if (message.type === "video") return message.video?.caption || "Видео";
  if (message.type === "system") return message.text;
  return message.text;
}

export async function hydrateSeedMedia(messages: Record<string, Message[]>): Promise<void> {
  const jobs: Promise<void>[] = [];
  for (const list of Object.values(messages)) {
    for (const message of list) {
      if (message.photo) {
        jobs.push(putMedia(message.photo.mediaId, makePatternPhoto(message.photo.mediaId)));
      }
    }
  }
  await Promise.all(jobs);
}

export function seedDevices(): Device[] {
  return [currentDeviceFingerprint()];
}

const DEVICE_KEY = "telechat.device-id";
const FAKE_DEVICE_IDS = new Set(["dev_iphone", "dev_mac", "dev_current"]);
const FAKE_IPS = new Set(["185.22.10.4", "95.24.11.8", "127.0.0.1"]);

export function currentDeviceFingerprint(): Device {
  const ua = typeof navigator === "undefined" ? "" : navigator.userAgent;
  let id = "dev_local";
  if (typeof window !== "undefined") {
    id = window.localStorage.getItem(DEVICE_KEY) ?? "";
    if (!id) {
      id = createId("dev");
      window.localStorage.setItem(DEVICE_KEY, id);
    }
  }
  const platform: Device["platform"] = /iPhone|iPad/i.test(ua)
    ? "ios"
    : /Android/i.test(ua)
      ? "android"
      : /Macintosh|Windows|Linux/i.test(ua) && !/Mobile/i.test(ua)
        ? "desktop"
        : "web";
  const name = /Edg\//i.test(ua)
    ? "Edge"
    : /Chrome/i.test(ua) && !/Edg\//i.test(ua)
      ? "Chrome"
      : /Firefox/i.test(ua)
        ? "Firefox"
        : /Safari/i.test(ua) && !/Chrome/i.test(ua)
          ? "Safari"
          : /iPhone/i.test(ua)
            ? "TeleChat iOS"
            : /Android/i.test(ua)
              ? "TeleChat Android"
              : "TeleChat";
  const host =
    platform === "ios"
      ? "iPhone"
      : platform === "android"
        ? "Android"
        : /Mac/i.test(ua)
          ? "Mac"
          : /Windows/i.test(ua)
            ? "Windows"
            : "браузер";
  const zone =
    typeof Intl !== "undefined"
      ? Intl.DateTimeFormat().resolvedOptions().timeZone.replace(/_/g, " ")
      : "Это устройство";
  return {
    id,
    name: `${name} · ${host}`,
    platform,
    location: zone,
    lastActive: Date.now(),
    current: true,
    ip: "",
  };
}

export function rememberRealDevices(existing: Device[] | undefined): Device[] {
  const current = currentDeviceFingerprint();
  const others = (existing ?? []).filter(
    (device) =>
      !FAKE_DEVICE_IDS.has(device.id) &&
      device.id !== current.id &&
      !FAKE_IPS.has(device.ip) &&
      !device.current,
  );
  return [current, ...others.map((device) => ({ ...device, current: false }))];
}

export { previewFrom };

export function pruneDemoChats(
  chats: Chat[],
  messages: Record<string, Message[]>,
): { chats: Chat[]; messages: Record<string, Message[]> } {
  const drop = new Set(DEMO_CHAT_IDS);
  return {
    chats: chats.filter((c) => !drop.has(c.id)),
    messages: Object.fromEntries(
      Object.entries(messages).filter(([id]) => !drop.has(id)),
    ),
  };
}
