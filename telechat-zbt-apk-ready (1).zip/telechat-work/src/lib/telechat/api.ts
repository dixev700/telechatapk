import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { createId, hueFromString, initialsFromName, TEAM_ID } from "@/lib/telechat/ids";
import type {
  AvatarSpec,
  Chat,
  Contact,
  Device,
  Message,
  Profile,
  ReactionId,
} from "@/lib/telechat/types";

export type DeviceInput = {
  id: string;
  name: string;
  platform: Device["platform"];
  location: string;
};

export type BootstrapPayload = {
  userId: string;
  email: string;
  profile: Profile | null;
  contacts: Contact[];
  chats: Chat[];
  messages: Record<string, Message[]>;
  devices: Device[];
  blockedIds: string[];
  theme: Profile extends never ? "dark" : "dark" | "light";
  wallpaper: string;
};

type ProfileRow = {
  user_id: string;
  email: string;
  display_name: string;
  username: string;
  avatar_json: string;
  bio: string;
  pin: string | null;
  theme: string;
  wallpaper: string;
  last_seen_privacy: string;
  read_receipts: boolean;
  notification_sound: boolean;
  font_size: string;
  created_at: number | string;
};

type ChatRow = {
  id: string;
  type: string;
  title: string;
  avatar_json: string;
  created_by: string;
  created_at: number | string;
  unread: number | string;
  muted: boolean;
  archived: boolean;
  pinned: boolean;
  deleted: boolean;
};

type MessageRow = {
  id: string;
  chat_id: string;
  sender_id: string;
  type: string;
  body: string;
  payload_json: string;
  reply_to_id: string | null;
  forwarded_json: string | null;
  reactions_json: string;
  deleted_for_all: boolean;
  created_at: number | string;
  hidden: boolean | null;
};

function num(value: number | string | null | undefined): number {
  return typeof value === "number" ? value : Number(value ?? 0);
}

function parseJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function officialAvatar(): AvatarSpec {
  return { kind: "gradient", hue: 199, initials: "TC" };
}

function officialContact(): Contact {
  return {
    id: TEAM_ID,
    displayName: "TeleChat",
    username: "telechat",
    avatar: officialAvatar(),
    bio: "Официальный аккаунт сервиса.",
    lastSeen: Date.now(),
    online: true,
    typing: false,
    isOfficial: true,
  };
}

function mapProfile(row: ProfileRow): Profile {
  return {
    id: row.user_id,
    email: row.email,
    displayName: row.display_name,
    username: row.username,
    avatar: parseJson<AvatarSpec>(row.avatar_json, {
      kind: "gradient",
      hue: 200,
      initials: "TC",
    }),
    bio: row.bio,
    pin: row.pin,
    createdAt: num(row.created_at),
    lastSeenPrivacy: (row.last_seen_privacy as Profile["lastSeenPrivacy"]) || "everyone",
    readReceipts: Boolean(row.read_receipts),
    notificationSound: Boolean(row.notification_sound),
    saveToGallery: false,
    fontSize: (row.font_size as Profile["fontSize"]) || "medium",
  };
}

function mapMessage(row: MessageRow): Message {
  const payload = parseJson<{
    voice?: Message["voice"];
    photo?: Message["photo"];
    video?: Message["video"];
  }>(row.payload_json, {});
  return {
    id: row.id,
    chatId: row.chat_id,
    senderId: row.sender_id,
    type: row.type as Message["type"],
    text: row.body,
    createdAt: num(row.created_at),
    editedAt: null,
    status: "delivered",
    replyToId: row.reply_to_id,
    forwarded: parseJson(row.forwarded_json, null),
    reactions: parseJson(row.reactions_json, {}),
    deletedForMe: Boolean(row.hidden),
    deletedForAll: Boolean(row.deleted_for_all),
    voice: payload.voice,
    photo: payload.photo,
    video: payload.video,
  };
}

function previewFrom(message: Message | undefined): string {
  if (!message || message.deletedForAll) return "";
  if (message.type === "voice") return "Голосовое сообщение";
  if (message.type === "photo") return message.photo?.caption || "Фото";
  if (message.type === "video") return message.video?.caption || "Видео";
  return message.text;
}

async function loadInbox(userId: string): Promise<{
  chats: Chat[];
  messages: Record<string, Message[]>;
  contacts: Contact[];
  blockedIds: string[];
}> {
  const sql = await getSql();
  const blocked = await sql<{ blocked_id: string }>`
    select blocked_id from tc_blocks where user_id = ${userId}
  `;
  const blockedIds = blocked.map((row) => row.blocked_id);

  const chatRows = await sql<ChatRow>`
    select c.id, c.type, c.title, c.avatar_json, c.created_by, c.created_at,
           m.unread, m.muted, m.archived, m.pinned, m.deleted
    from tc_chats c
    join tc_chat_members m on m.chat_id = c.id
    where m.user_id = ${userId}
    order by c.created_at desc
  `;

  const memberRows = await sql<{ chat_id: string; user_id: string }>`
    select chat_id, user_id from tc_chat_members
    where chat_id in (select chat_id from tc_chat_members where user_id = ${userId})
  `;
  const membersByChat = new Map<string, string[]>();
  for (const row of memberRows) {
    const list = membersByChat.get(row.chat_id) ?? [];
    list.push(row.user_id);
    membersByChat.set(row.chat_id, list);
  }

  const msgRows = await sql<MessageRow>`
    select msg.*,
           case when h.user_id is null then false else true end as hidden
    from tc_messages msg
    left join tc_message_hidden h
      on h.message_id = msg.id and h.user_id = ${userId}
    where msg.chat_id in (select chat_id from tc_chat_members where user_id = ${userId})
    order by msg.created_at asc
  `;

  const messages: Record<string, Message[]> = {};
  for (const row of msgRows) {
    const list = messages[row.chat_id] ?? [];
    list.push(mapMessage(row));
    messages[row.chat_id] = list;
  }

  const chats: Chat[] = chatRows.map((row) => {
    const list = (messages[row.id] ?? []).filter((m) => !m.deletedForMe);
    const last = [...list].reverse().find((m) => !m.deletedForAll);
    return {
      id: row.id,
      type: row.type as Chat["type"],
      title: row.title,
      avatar: parseJson<AvatarSpec>(row.avatar_json, officialAvatar()),
      participantIds: membersByChat.get(row.id) ?? [userId],
      lastMessagePreview: previewFrom(last),
      lastMessageAt: last?.createdAt ?? num(row.created_at),
      unread: num(row.unread),
      muted: Boolean(row.muted),
      archived: Boolean(row.archived),
      pinned: Boolean(row.pinned),
      pinnedMessageId: null,
      createdAt: num(row.created_at),
      createdBy: row.created_by,
      deletedForMe: Boolean(row.deleted),
    };
  });

  const otherIds = Array.from(
    new Set(
      memberRows.map((row) => row.user_id).filter((id) => id !== userId && id !== TEAM_ID),
    ),
  );
  const profileRows: ProfileRow[] = [];
  for (const id of otherIds) {
    const found = await sql<ProfileRow>`select * from tc_profiles where user_id = ${id}`;
    if (found[0]) profileRows.push(found[0]);
  }

  const contacts: Contact[] = [officialContact()];
  for (const row of profileRows) {
    const mapped = mapProfile(row);
    contacts.push({
      id: mapped.id,
      displayName: mapped.displayName,
      username: mapped.username,
      avatar: mapped.avatar,
      bio: mapped.bio,
      lastSeen: Date.now(),
      online: true,
      typing: false,
      isBlocked: blockedIds.includes(mapped.id),
    });
  }

  return { chats, messages, contacts, blockedIds };
}

async function ensureOfficialChat(userId: string, displayName: string) {
  const sql = await getSql();
  const chatId = `sys_${userId}`;
  const existing = await sql<{ id: string }>`select id from tc_chats where id = ${chatId}`;
  if (existing[0]) return chatId;
  const now = Date.now();
  await sql`
    insert into tc_chats (id, type, title, avatar_json, created_by, created_at)
    values (${chatId}, ${"direct"}, ${"TeleChat"}, ${JSON.stringify(officialAvatar())}, ${TEAM_ID}, ${now})
  `;
  await sql`
    insert into tc_chat_members (chat_id, user_id, unread, muted, archived, pinned, deleted, last_read_at)
    values
      (${chatId}, ${userId}, 1, false, false, true, false, 0),
      (${chatId}, ${TEAM_ID}, 0, false, false, false, false, 0)
  `;
  const welcome = [
    `Это TeleChat. Сообщения теперь хранятся на сервере — их видно с любого вашего устройства.`,
    `${displayName}, добро пожаловать. Зажмите чат, чтобы закрепить, заблокировать или удалить.`,
  ];
  for (const text of welcome) {
    await sql`
      insert into tc_messages (id, chat_id, sender_id, type, body, payload_json, reactions_json, deleted_for_all, created_at)
      values (${createId("msg")}, ${chatId}, ${TEAM_ID}, ${"text"}, ${text}, ${"{}"}, ${"{}"}, false, ${Date.now()})
    `;
  }
  return chatId;
}

async function assertMember(userId: string, chatId: string) {
  const sql = await getSql();
  const rows = await sql<{ user_id: string }>`
    select user_id from tc_chat_members where chat_id = ${chatId} and user_id = ${userId} and deleted = false
  `;
  if (!rows[0]) throw new Error("Forbidden");
}

async function runBootstrap(
  userId: string,
  email: string,
  device: DeviceInput,
): Promise<BootstrapPayload> {
  const sql = await getSql();
  const profiles = await sql<ProfileRow>`select * from tc_profiles where user_id = ${userId}`;
  const profile = profiles[0] ? mapProfile(profiles[0]) : null;
  if (profile) {
    await ensureOfficialChat(userId, profile.displayName);
  }

  const now = Date.now();
  const existingDev = await sql<{ id: string }>`
    select id from tc_devices where id = ${device.id} and user_id = ${userId}
  `;
  if (existingDev[0]) {
    await sql`
      update tc_devices
      set name = ${device.name}, platform = ${device.platform}, location = ${device.location}, last_active = ${now}
      where id = ${device.id} and user_id = ${userId}
    `;
  } else {
    await sql`
      insert into tc_devices (id, user_id, name, platform, location, last_active, created_at)
      values (${device.id}, ${userId}, ${device.name}, ${device.platform}, ${device.location}, ${now}, ${now})
    `;
  }

  const deviceRows = await sql<{
    id: string;
    name: string;
    platform: string;
    location: string;
    last_active: number | string;
  }>`select id, name, platform, location, last_active from tc_devices where user_id = ${userId} order by last_active desc`;

  const inbox = profile
    ? await loadInbox(userId)
    : { chats: [], messages: {}, contacts: [officialContact()], blockedIds: [] };

  return {
    userId,
    email,
    profile,
    contacts: inbox.contacts,
    chats: inbox.chats,
    messages: inbox.messages,
    devices: deviceRows.map((row) => ({
      id: row.id,
      name: row.name,
      platform: row.platform as Device["platform"],
      location: row.location,
      lastActive: num(row.last_active),
      current: row.id === device.id,
      ip: "",
    })),
    blockedIds: inbox.blockedIds,
    theme: (profiles[0]?.theme as "dark" | "light") || "dark",
    wallpaper: profiles[0]?.wallpaper ?? "ink",
  };
}

export const bootstrapSession = createServerFn({ method: "POST" })
  .validator((device: DeviceInput) => device)
  .middleware([authMiddleware])
  .handler(async ({ context, data: device }): Promise<BootstrapPayload> => {
    const { getSessionUser } = await import("@/lib/auth/verify.server");
    const sessionUser = await getSessionUser();
    return runBootstrap(context.userId, sessionUser?.email ?? "", device);
  });

export const createProfile = createServerFn({ method: "POST" })
  .validator((input: { displayName: string; username: string; device: DeviceInput }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<BootstrapPayload> => {
    const sql = await getSql();
    const userId = context.userId;
    const username = data.username.trim().toLowerCase().replace(/^@/, "");
    if (username.length < 5 || username.length > 32 || !/^[a-z][a-z0-9_]+$/.test(username)) {
      throw new Error("invalid-username");
    }
    if (username === "telechat") throw new Error("username-taken");
    const taken = await sql<{ user_id: string }>`select user_id from tc_profiles where username = ${username}`;
    if (taken[0] && taken[0].user_id !== userId) throw new Error("username-taken");

    const { getSessionUser } = await import("@/lib/auth/verify.server");
    const sessionUser = await getSessionUser();
    const email = sessionUser?.email ?? "";
    const displayName = data.displayName.trim();
    const avatar: AvatarSpec = {
      kind: "gradient",
      hue: hueFromString(displayName),
      initials: initialsFromName(displayName),
    };
    const now = Date.now();
    const existing = await sql<{ user_id: string }>`select user_id from tc_profiles where user_id = ${userId}`;
    if (existing[0]) {
      await sql`
        update tc_profiles
        set display_name = ${displayName}, username = ${username}, email = ${email}
        where user_id = ${userId}
      `;
    } else {
      await sql`
        insert into tc_profiles (
          user_id, email, display_name, username, avatar_json, bio, pin, theme, wallpaper,
          last_seen_privacy, read_receipts, notification_sound, font_size, created_at
        ) values (
          ${userId}, ${email}, ${displayName}, ${username}, ${JSON.stringify(avatar)},
          ${"Привет, я в TeleChat."}, null, ${"dark"}, ${"ink"},
          ${"everyone"}, true, true, ${"medium"}, ${now}
        )
      `;
    }
    await ensureOfficialChat(userId, displayName);
    const { getSessionUser: getUser } = await import("@/lib/auth/verify.server");
    const signed = await getUser();
    return runBootstrap(userId, signed?.email ?? email, data.device);
  });

export const saveProfile = createServerFn({ method: "POST" })
  .validator((patch: Partial<Profile> & { theme?: string; wallpaper?: string }) => patch)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<ProfileRow>`select * from tc_profiles where user_id = ${context.userId}`;
    if (!rows[0]) return;
    const current = mapProfile(rows[0]);
    const next = { ...current, ...data };
    if (data.username && data.username !== current.username) {
      const taken = await sql<{ user_id: string }>`select user_id from tc_profiles where username = ${data.username}`;
      if (taken[0]) throw new Error("username-taken");
    }
    await sql`
      update tc_profiles set
        display_name = ${next.displayName},
        username = ${next.username},
        avatar_json = ${JSON.stringify(next.avatar)},
        bio = ${next.bio},
        pin = ${next.pin},
        theme = ${data.theme ?? rows[0].theme},
        wallpaper = ${data.wallpaper ?? rows[0].wallpaper},
        last_seen_privacy = ${next.lastSeenPrivacy},
        read_receipts = ${next.readReceipts},
        notification_sound = ${next.notificationSound},
        font_size = ${next.fontSize}
      where user_id = ${context.userId}
    `;
  });

export const pullInbox = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => loadInbox(context.userId));

export const searchPeople = createServerFn({ method: "POST" })
  .validator((query: string) => query.trim().toLowerCase().replace(/^@/, ""))
  .middleware([authMiddleware])
  .handler(async ({ context, data: query }): Promise<Contact[]> => {
    if (!query) return [];
    const sql = await getSql();
    const like = `%${query}%`;
    const rows = await sql<ProfileRow>`
      select * from tc_profiles
      where user_id <> ${context.userId}
        and (username like ${like} or lower(display_name) like ${like})
      limit 30
    `;
    return rows.map((row) => {
      const mapped = mapProfile(row);
      return {
        id: mapped.id,
        displayName: mapped.displayName,
        username: mapped.username,
        avatar: mapped.avatar,
        bio: mapped.bio,
        lastSeen: Date.now(),
        online: true,
        typing: false,
      };
    });
  });

type SendInput = {
  chatId: string;
  type: Message["type"];
  text: string;
  payload?: { voice?: Message["voice"]; photo?: Message["photo"]; video?: Message["video"] };
  forwarded?: Message["forwarded"];
  replyToId?: string | null;
};

export const sendServerMessage = createServerFn({ method: "POST" })
  .validator((input: SendInput) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Message> => {
    await assertMember(context.userId, data.chatId);
    const sql = await getSql();
    const message: Message = {
      id: createId("msg"),
      chatId: data.chatId,
      senderId: context.userId,
      type: data.type,
      text: data.text,
      createdAt: Date.now(),
      editedAt: null,
      status: "sent",
      replyToId: data.replyToId ?? null,
      forwarded: data.forwarded ?? null,
      reactions: {},
      deletedForMe: false,
      deletedForAll: false,
      voice: data.payload?.voice,
      photo: data.payload?.photo,
      video: data.payload?.video,
    };
    await sql`
      insert into tc_messages (
        id, chat_id, sender_id, type, body, payload_json, reply_to_id, forwarded_json, reactions_json, deleted_for_all, created_at
      ) values (
        ${message.id}, ${message.chatId}, ${message.senderId}, ${message.type}, ${message.text},
        ${JSON.stringify({ voice: message.voice, photo: message.photo, video: message.video })},
        ${message.replyToId}, ${message.forwarded ? JSON.stringify(message.forwarded) : null},
        ${"{}"}, false, ${message.createdAt}
      )
    `;
    await sql`
      update tc_chat_members
      set unread = unread + 1
      where chat_id = ${data.chatId} and user_id <> ${context.userId}
    `;

    const others = await sql<{ user_id: string }>`
      select user_id from tc_chat_members where chat_id = ${data.chatId} and user_id <> ${context.userId}
    `;
    if (others.some((row) => row.user_id === TEAM_ID) && data.type === "text") {
      const replyText = pickOfficialReply(data.text);
      const reply: Message = {
        id: createId("msg"),
        chatId: data.chatId,
        senderId: TEAM_ID,
        type: "text",
        text: replyText,
        createdAt: Date.now() + 1,
        editedAt: null,
        status: "delivered",
        replyToId: null,
        forwarded: null,
        reactions: {},
        deletedForMe: false,
        deletedForAll: false,
      };
      await sql`
        insert into tc_messages (
          id, chat_id, sender_id, type, body, payload_json, reactions_json, deleted_for_all, created_at
        ) values (
          ${reply.id}, ${reply.chatId}, ${reply.senderId}, ${"text"}, ${reply.text}, ${"{}"}, ${"{}"}, false, ${reply.createdAt}
        )
      `;
      await sql`
        update tc_chat_members set unread = unread + 1
        where chat_id = ${data.chatId} and user_id = ${context.userId}
      `;
    }
    return message;
  });

function pickOfficialReply(text: string): string {
  if (/привет|здравств|хай/i.test(text)) return "Привет! Чем помочь?";
  if (/парол|пин|код/i.test(text)) return "Код-пароль включается в Настройках. Он только на этом аккаунте.";
  if (/\?/.test(text)) return "Хороший вопрос. Напишите подробнее — служба TeleChat ответит.";
  return "Сообщение доставлено. Если нужна помощь по аккаунту — напишите сюда.";
}

export const createDirectChatFn = createServerFn({ method: "POST" })
  .validator((contactId: string) => contactId)
  .middleware([authMiddleware])
  .handler(async ({ context, data: contactId }): Promise<{ chat: Chat; messages: Message[] }> => {
    const sql = await getSql();
    const mine = await sql<{ chat_id: string }>`
      select a.chat_id
      from tc_chat_members a
      join tc_chat_members b on a.chat_id = b.chat_id
      join tc_chats c on c.id = a.chat_id
      where a.user_id = ${context.userId} and b.user_id = ${contactId} and c.type = 'direct'
        and a.deleted = false
    `;
    if (mine[0]) {
      const inbox = await loadInbox(context.userId);
      const chat = inbox.chats.find((c) => c.id === mine[0].chat_id);
      if (chat) {
        await sql`update tc_chat_members set deleted = false where chat_id = ${chat.id} and user_id = ${context.userId}`;
        return { chat, messages: inbox.messages[chat.id] ?? [] };
      }
    }
    const now = Date.now();
    const chatId = createId("chat");
    let title = "Чат";
    let avatar: AvatarSpec = officialAvatar();
    if (contactId === TEAM_ID) {
      title = "TeleChat";
    } else {
      const rows = await sql<ProfileRow>`select * from tc_profiles where user_id = ${contactId}`;
      if (!rows[0]) throw new Error("not-found");
      const person = mapProfile(rows[0]);
      title = person.displayName;
      avatar = person.avatar;
    }
    await sql`
      insert into tc_chats (id, type, title, avatar_json, created_by, created_at)
      values (${chatId}, ${"direct"}, ${title}, ${JSON.stringify(avatar)}, ${context.userId}, ${now})
    `;
    await sql`
      insert into tc_chat_members (chat_id, user_id, unread, muted, archived, pinned, deleted, last_read_at)
      values
        (${chatId}, ${context.userId}, 0, false, false, false, false, ${now}),
        (${chatId}, ${contactId}, 0, false, false, false, false, 0)
    `;
    const chat: Chat = {
      id: chatId,
      type: "direct",
      title,
      avatar,
      participantIds: [context.userId, contactId],
      lastMessagePreview: "",
      lastMessageAt: now,
      unread: 0,
      muted: false,
      archived: false,
      pinned: false,
      pinnedMessageId: null,
      createdAt: now,
      createdBy: context.userId,
      deletedForMe: false,
    };
    return { chat, messages: [] };
  });

export const createGroupFn = createServerFn({ method: "POST" })
  .validator((input: { title: string; memberIds: string[] }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ chat: Chat; messages: Message[] }> => {
    const sql = await getSql();
    const title = data.title.trim();
    if (!title) throw new Error("invalid-title");
    const now = Date.now();
    const chatId = createId("grp");
    const avatar: AvatarSpec = {
      kind: "gradient",
      hue: hueFromString(title),
      initials: initialsFromName(title),
    };
    await sql`
      insert into tc_chats (id, type, title, avatar_json, created_by, created_at)
      values (${chatId}, ${"group"}, ${title}, ${JSON.stringify(avatar)}, ${context.userId}, ${now})
    `;
    const members = Array.from(new Set([context.userId, ...data.memberIds]));
    for (const id of members) {
      await sql`
        insert into tc_chat_members (chat_id, user_id, unread, muted, archived, pinned, deleted, last_read_at)
        values (${chatId}, ${id}, 0, false, false, false, false, 0)
      `;
    }
    const systemId = createId("msg");
    const text = `Вы создали группу «${title}»`;
    await sql`
      insert into tc_messages (id, chat_id, sender_id, type, body, payload_json, reactions_json, deleted_for_all, created_at)
      values (${systemId}, ${chatId}, ${context.userId}, ${"system"}, ${text}, ${"{}"}, ${"{}"}, false, ${now})
    `;
    const chat: Chat = {
      id: chatId,
      type: "group",
      title,
      avatar,
      participantIds: members,
      lastMessagePreview: text,
      lastMessageAt: now,
      unread: 0,
      muted: false,
      archived: false,
      pinned: false,
      pinnedMessageId: null,
      createdAt: now,
      createdBy: context.userId,
      deletedForMe: false,
    };
    return {
      chat,
      messages: [
        {
          id: systemId,
          chatId,
          senderId: context.userId,
          type: "system",
          text,
          createdAt: now,
          editedAt: null,
          status: "sent",
          replyToId: null,
          forwarded: null,
          reactions: {},
          deletedForMe: false,
          deletedForAll: false,
        },
      ],
    };
  });

export const mutateChatFn = createServerFn({ method: "POST" })
  .validator(
    (input: {
      chatId: string;
      action: "archive" | "mute" | "pin" | "delete-me" | "delete-all" | "clear" | "read";
      value?: boolean;
    }) => input,
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    await assertMember(context.userId, data.chatId);
    const sql = await getSql();
    if (data.action === "archive") {
      await sql`update tc_chat_members set archived = ${Boolean(data.value)} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    } else if (data.action === "mute") {
      await sql`update tc_chat_members set muted = ${Boolean(data.value)} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    } else if (data.action === "pin") {
      await sql`update tc_chat_members set pinned = ${Boolean(data.value)} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    } else if (data.action === "delete-me") {
      await sql`update tc_chat_members set deleted = true, unread = 0 where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    } else if (data.action === "delete-all") {
      const chat = await sql<{ created_by: string }>`select created_by from tc_chats where id = ${data.chatId}`;
      if (chat[0]?.created_by !== context.userId) throw new Error("Forbidden");
      await sql`delete from tc_messages where chat_id = ${data.chatId}`;
      await sql`delete from tc_chat_members where chat_id = ${data.chatId}`;
      await sql`delete from tc_chats where id = ${data.chatId}`;
    } else if (data.action === "clear") {
      await sql`delete from tc_messages where chat_id = ${data.chatId}`;
      const now = Date.now();
      await sql`
        insert into tc_messages (id, chat_id, sender_id, type, body, payload_json, reactions_json, deleted_for_all, created_at)
        values (${createId("msg")}, ${data.chatId}, ${context.userId}, ${"system"}, ${"История очищена"}, ${"{}"}, ${"{}"}, false, ${now})
      `;
    } else if (data.action === "read") {
      await sql`update tc_chat_members set unread = 0, last_read_at = ${Date.now()} where chat_id = ${data.chatId} and user_id = ${context.userId}`;
    }
  });

export const mutateMessageFn = createServerFn({ method: "POST" })
  .validator(
    (input: {
      chatId: string;
      messageId: string;
      action: "react" | "delete-me" | "delete-all";
      reaction?: ReactionId;
    }) => input,
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    await assertMember(context.userId, data.chatId);
    const sql = await getSql();
    if (data.action === "delete-me") {
      await sql`
        insert into tc_message_hidden (message_id, user_id)
        values (${data.messageId}, ${context.userId})
        on conflict do nothing
      `;
      return;
    }
    const rows = await sql<MessageRow>`select * from tc_messages where id = ${data.messageId} and chat_id = ${data.chatId}`;
    const row = rows[0];
    if (!row) return;
    if (data.action === "delete-all") {
      if (row.sender_id !== context.userId) throw new Error("Forbidden");
      await sql`update tc_messages set deleted_for_all = true, body = '', payload_json = '{}' where id = ${data.messageId}`;
      return;
    }
    if (data.action === "react" && data.reaction) {
      const reactions = parseJson<Partial<Record<ReactionId, string[]>>>(row.reactions_json, {});
      const list = new Set(reactions[data.reaction] ?? []);
      if (list.has(context.userId)) list.delete(context.userId);
      else list.add(context.userId);
      reactions[data.reaction] = Array.from(list);
      await sql`update tc_messages set reactions_json = ${JSON.stringify(reactions)} where id = ${data.messageId}`;
    }
  });

export const terminateDeviceFn = createServerFn({ method: "POST" })
  .validator((deviceId: string) => deviceId)
  .middleware([authMiddleware])
  .handler(async ({ context, data: deviceId }) => {
    const sql = await getSql();
    await sql`delete from tc_devices where id = ${deviceId} and user_id = ${context.userId}`;
  });

export const blockContactFn = createServerFn({ method: "POST" })
  .validator((input: { contactId: string; blocked: boolean }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    if (data.blocked) {
      await sql`
        insert into tc_blocks (user_id, blocked_id)
        values (${context.userId}, ${data.contactId})
        on conflict do nothing
      `;
    } else {
      await sql`delete from tc_blocks where user_id = ${context.userId} and blocked_id = ${data.contactId}`;
    }
  });
