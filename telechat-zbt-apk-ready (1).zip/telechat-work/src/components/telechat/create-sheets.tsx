import { useState } from "react";
import { useShallow } from "zustand/react/shallow";
import { Overlay } from "@/components/telechat/sheet";
import { UserAvatar } from "@/components/telechat/user-avatar";
import { t } from "@/lib/telechat/constants";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function CreateDirectSheet() {
  const contacts = useTelechat(useShallow((s) => s.contacts.filter((c) => !c.isBlocked)));
  const [q, setQ] = useState("");
  const filtered = contacts.filter((c) => {
    const s = q.toLowerCase().replace(/^@/, "");
    if (!s) return true;
    return c.displayName.toLowerCase().includes(s) || c.username.includes(s);
  });

  return (
    <Overlay
      open
      onClose={() => useTelechat.getState().setCreateMode(null)}
      className="max-h-[82vh] overflow-hidden"
    >
      <h2 className="text-lg font-semibold tracking-tight">{t.newChat}</h2>
      <input
        autoFocus
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={t.searchContacts}
        className="mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-[15px] outline-none"
      />
      <div className="mt-2 max-h-[50vh] overflow-y-auto">
        {filtered.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => useTelechat.getState().createDirectChat(c.id)}
            className="tap flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-left"
          >
            <UserAvatar avatar={c.avatar} size="sm" online={c.online} />
            <span className="min-w-0">
              <span className="block truncate font-medium">{c.displayName}</span>
              <span className="text-xs text-muted">@{c.username}</span>
            </span>
          </button>
        ))}
      </div>
    </Overlay>
  );
}

export function CreateGroupSheet() {
  const contacts = useTelechat(
    useShallow((s) => s.contacts.filter((c) => !c.isOfficial && !c.isBlocked)),
  );
  const [title, setTitle] = useState("");
  const [picked, setPicked] = useState<string[]>([]);

  const toggle = (id: string) => {
    setPicked((list) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]));
  };

  return (
    <Overlay
      open
      onClose={() => useTelechat.getState().setCreateMode(null)}
      className="max-h-[86vh] overflow-hidden"
    >
      <h2 className="text-lg font-semibold tracking-tight">{t.newGroup}</h2>
      <input
        autoFocus
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder={t.groupName}
        className="mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-[15px] outline-none"
      />
      <p className="mt-4 text-xs font-medium text-muted">{t.addMembers}</p>
      <div className="mt-1 max-h-[40vh] overflow-y-auto">
        {contacts.map((c) => {
          const on = picked.includes(c.id);
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => toggle(c.id)}
              className="tap flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-left"
            >
              <UserAvatar avatar={c.avatar} size="sm" />
              <span className="min-w-0 flex-1 font-medium">{c.displayName}</span>
              <span
                className={cn(
                  "flex size-5 items-center justify-center rounded-full border",
                  on ? "border-accent bg-accent" : "border-border-strong",
                )}
              />
            </button>
          );
        })}
      </div>
      <button
        type="button"
        disabled={!title.trim() || picked.length === 0}
        onClick={() => useTelechat.getState().createGroup(title, picked)}
        className="tap mt-4 h-11 w-full rounded-2xl bg-accent text-sm font-semibold text-accent-fg disabled:opacity-40"
      >
        {t.create}
      </button>
    </Overlay>
  );
}

export function ForwardSheet() {
  const messageId = useTelechat((s) => s.ui.forwardMessageId);
  const chats = useTelechat(
    useShallow((s) =>
      s.chats
        .filter((c) => !c.deletedForMe && !c.archived)
        .sort((a, b) => b.lastMessageAt - a.lastMessageAt),
    ),
  );
  if (!messageId) return null;
  return (
    <Overlay open onClose={() => useTelechat.getState().setForwardMessage(null)} className="max-h-[80vh] overflow-hidden">
      <h2 className="text-lg font-semibold tracking-tight">{t.forward}</h2>
      <div className="mt-3 max-h-[55vh] overflow-y-auto">
        {chats.map((chat) => (
          <button
            key={chat.id}
            type="button"
            onClick={() => {
              useTelechat.getState().forwardMessage(messageId, chat.id);
              useTelechat.getState().openChat(chat.id);
            }}
            className="tap flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-left"
          >
            <UserAvatar avatar={chat.avatar} size="sm" />
            <span className="min-w-0">
              <span className="block truncate font-medium">{chat.title}</span>
              <span className="text-xs text-muted">{chat.lastMessagePreview}</span>
            </span>
          </button>
        ))}
      </div>
    </Overlay>
  );
}
