import { X } from "lucide-react";
import { useEffect, useState } from "react";
import { getMedia } from "@/lib/telechat/storage";
import { findMessage, useTelechat } from "@/store/telechat-store";

export function MediaViewer() {
  const viewer = useTelechat((s) => s.ui.mediaViewer);
  const message = useTelechat((s) =>
    viewer ? findMessage(s, viewer.messageId) : undefined,
  );
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    const id = message?.photo?.mediaId ?? message?.video?.mediaId;
    if (!id) {
      setSrc(null);
      return;
    }
    void getMedia(id).then(setSrc);
  }, [message]);

  if (!viewer || !message) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/92">
      <button
        type="button"
        onClick={() => useTelechat.getState().openMedia("", null)}
        className="tap absolute top-[max(0.8rem,env(safe-area-inset-top))] right-3 z-10 flex size-11 items-center justify-center rounded-full bg-white/10 text-white"
        aria-label="Закрыть"
      >
        <X className="size-5" />
      </button>
      <div className="flex min-h-0 flex-1 items-center justify-center p-4">
        {message.type === "video" && src ? (
          <video src={src} controls autoPlay className="max-h-full max-w-full rounded-2xl" />
        ) : src ? (
          <img src={src} alt={message.text || "Медиа"} className="max-h-full max-w-full rounded-2xl object-contain" />
        ) : (
          <p className="text-sm text-white/70">Загрузка…</p>
        )}
      </div>
      {message.text ? (
        <p className="px-6 pb-8 text-center text-sm text-white/80">{message.text}</p>
      ) : null}
    </div>
  );
}
