import { BellOff, ShieldBan, Trash2, Volume2, X } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { UserAvatar } from "@/components/telechat/user-avatar";
import { formatLastSeen, formatMembers, withAt } from "@/lib/telechat/format";
import { ME_ID } from "@/lib/telechat/ids";
import { chatPeer, useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function ChatInfo({ chatId, onClose }: { chatId: string; onClose: () => void }) {
  const chat = useTelechat((s) => s.chats.find((c) => c.id === chatId));
  const peer = useTelechat((s) => (chat ? chatPeer(s, chat) : undefined));
  const members = useTelechat(
    useShallow((s) =>
      (chat?.participantIds ?? [])
        .filter((id) => id !== ME_ID)
        .map((id) => s.contacts.find((c) => c.id === id))
        .filter(Boolean),
    ),
  );
  const media = useTelechat(
    useShallow((s) =>
      (s.messages[chatId] ?? []).filter(
        (m) => (m.type === "photo" || m.type === "video") && !m.deletedForAll && !m.deletedForMe,
      ),
    ),
  );
  if (!chat) return null;

  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-bg">
      <header className="flex items-center justify-between px-2 pt-[max(0.6rem,env(safe-area-inset-top))]">
        <button type="button" onClick={onClose} className="tap flex size-11 items-center justify-center rounded-2xl" aria-label="Закрыть">
          <X className="size-5" />
        </button>
        <h2 className="font-semibold">Информация</h2>
        <span className="size-11" />
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-8">
        <div className="mt-4 flex flex-col items-center">
          <UserAvatar avatar={chat.avatar} size="xl" />
          <h3 className="mt-3 text-xl font-semibold tracking-tight">{chat.title}</h3>
          <p className="text-sm text-muted">
            {chat.type === "group"
              ? formatMembers(chat.participantIds.length)
              : peer && "username" in peer
                ? withAt(peer.username)
                : ""}
          </p>
          {peer && "bio" in peer ? <p className="mt-2 max-w-sm text-center text-sm text-muted">{peer.bio}</p> : null}
          {peer && "lastSeen" in peer ? (
            <p className="mt-1 text-xs text-subtle">
              {peer.online ? "в сети" : formatLastSeen(peer.lastSeen)}
            </p>
          ) : null}
        </div>
        <div className="mt-6 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => useTelechat.getState().muteChat(chatId, !chat.muted)}
            className="tap flex h-12 items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium"
          >
            {chat.muted ? <Volume2 className="size-4" /> : <BellOff className="size-4" />}
            {chat.muted ? "Звук" : "Без звука"}
          </button>
          {chat.type === "direct" && peer && "online" in peer ? (
            <button
              type="button"
              onClick={() => useTelechat.getState().blockContact(peer.id, !(peer.isBlocked ?? false))}
              className="tap flex h-12 items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium text-danger"
            >
              <ShieldBan className="size-4" />
              {peer.isBlocked ? "Разблок." : "Блок"}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => useTelechat.getState().deleteChat(chatId, false)}
              className="tap flex h-12 items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium text-danger"
            >
              <Trash2 className="size-4" />
              Удалить
            </button>
          )}
        </div>
        {chat.description ? (
          <p className="mt-5 rounded-2xl bg-surface px-4 py-3 text-sm leading-relaxed">{chat.description}</p>
        ) : null}
        {chat.type === "group" ? (
          <div className="mt-6">
            <p className="mb-2 text-xs font-medium text-muted">Участники</p>
            <div className="overflow-hidden rounded-3xl bg-surface">
              {members.map((m) =>
                m ? (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => useTelechat.getState().createDirectChat(m.id)}
                    className="tap flex w-full items-center gap-3 px-3 py-2.5 text-left"
                  >
                    <UserAvatar avatar={m.avatar} size="sm" online={m.online} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-medium">{m.displayName}</span>
                      <span className="text-xs text-muted">@{m.username}</span>
                    </span>
                  </button>
                ) : null,
              )}
            </div>
          </div>
        ) : null}
        <div className="mt-6">
          <p className="mb-2 text-xs font-medium text-muted">Медиа</p>
          {media.length === 0 ? (
            <p className="rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted">В этом чате ещё нет медиа</p>
          ) : (
            <div className="grid grid-cols-3 gap-1">
              {media.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => useTelechat.getState().openMedia(chatId, m.id)}
                  className={cn("aspect-square overflow-hidden rounded-xl bg-surface-2")}
                >
                  <span className="flex size-full items-center justify-center text-xs text-muted">
                    {m.type === "video" ? "Видео" : "Фото"}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
