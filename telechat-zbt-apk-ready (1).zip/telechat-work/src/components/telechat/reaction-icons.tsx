import type { ReactNode } from "react";
import type { ReactionId } from "@/lib/telechat/types";
import { cn } from "@/lib/utils";

function wrap(children: ReactNode, className?: string) {
  return (
    <svg viewBox="0 0 24 24" className={cn("size-4", className)} aria-hidden="true">
      {children}
    </svg>
  );
}

export function ReactionIcon({
  id,
  className,
}: {
  id: ReactionId;
  className?: string;
}) {
  switch (id) {
    case "heart":
      return wrap(
        <path
          d="M12 20s-7-4.4-9.2-8.4C1 8.4 3.2 5 6.6 5c2 0 3.3 1.1 5.4 3.2C14.1 6.1 15.4 5 17.4 5c3.4 0 5.6 3.4 3.8 6.6C19 15.6 12 20 12 20Z"
          fill="currentColor"
        />,
        cn("text-[#e25b73]", className),
      );
    case "like":
      return wrap(
        <path
          d="M8 11v9H5.2A1.2 1.2 0 0 1 4 18.8V12.2A1.2 1.2 0 0 1 5.2 11H8Zm2 9 6.3-0.8c.8-.1 1.5-.7 1.7-1.5l1.2-4.6c.3-1.2-.6-2.3-1.8-2.3H14l.7-3.2c.2-1-.8-1.8-1.8-1.5L9.4 7.6A2 2 0 0 0 8 9.5V20h2Z"
          fill="currentColor"
        />,
        cn("text-accent", className),
      );
    case "fire":
      return wrap(
        <path
          d="M12 3c2 3-1 4.5 1 7 1.4 1.8 4 1.5 4 5.2 0 3.3-2.8 6-7 6s-7-2.7-7-6c0-3.2 2.2-5 3.6-6.6C8.4 6.6 10 5.4 12 3Z"
          fill="currentColor"
        />,
        cn("text-[#e8893a]", className),
      );
    case "laugh":
      return wrap(
        <>
          <circle cx="12" cy="12" r="9" fill="currentColor" />
          <circle cx="9" cy="10" r="1.15" fill="#1b140f" />
          <circle cx="15" cy="10" r="1.15" fill="#1b140f" />
          <path d="M8 13.5c.8 2.4 7.2 2.4 8 0" stroke="#1b140f" strokeWidth="1.4" fill="none" strokeLinecap="round" />
        </>,
        cn("text-[#e7c04a]", className),
      );
    case "wow":
      return wrap(
        <>
          <circle cx="12" cy="12" r="9" fill="currentColor" />
          <circle cx="9" cy="10" r="1.2" fill="#1b140f" />
          <circle cx="15" cy="10" r="1.2" fill="#1b140f" />
          <ellipse cx="12" cy="15.4" rx="1.5" ry="2" fill="#1b140f" />
        </>,
        cn("text-[#7fb3e8]", className),
      );
    case "sad":
      return wrap(
        <>
          <circle cx="12" cy="12" r="9" fill="currentColor" />
          <circle cx="9" cy="10.2" r="1.15" fill="#1b140f" />
          <circle cx="15" cy="10.2" r="1.15" fill="#1b140f" />
          <path d="M8.5 16.4c1.1-1.6 5.9-1.6 7 0" stroke="#1b140f" strokeWidth="1.4" fill="none" strokeLinecap="round" />
        </>,
        cn("text-[#8aa0c2]", className),
      );
  }
}
