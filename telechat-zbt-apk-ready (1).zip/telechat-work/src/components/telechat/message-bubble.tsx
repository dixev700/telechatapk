import { Check, CheckCheck, Play } from "lucide-react";
import { useEffect, useState, type MouseEvent, type TouchEvent } from "react";
import { ReactionIcon } from "@/components/telechat/reaction-icons";
import { UserAvatar } from "@/components/telechat/user-avatar";
import { VoicePlayer } from "@/components/telechat/voice-player";
import { formatTime } from "@/lib/telechat/format";
import { ME_ID } from "@/lib/telechat/ids";
import { getMedia } from "@/lib/telechat/storage";
import type { Message, ReactionId } from "@/lib/telechat/types";
import { REACTIONS } from "@/lib/telechat/constants";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function MessageBubble({
  message,
  grouped,
  onLongPress,
}: {
  message: Message;
  grouped?: boolean;
  onLongPress: (message: Message, x: number, y: number) => void;
}) {
  const mine = message.senderId === ME_ID;
  const sender = useTelechat((s) =>
    s.contacts.find((c) => c.id === message.senderId),
  );
  const chat = useTelechat((s) => s.chats.find((c) => c.id === message.chatId));
  const isGroup = chat?.type === "group";

  if (message.deletedForMe) return null;
  if (message.type === "system") {
    return (
      <div className="mx-auto max-w-[80%] rounded-full bg-surface/80 px-3 py-1 text-center text-[11px] text-muted">
        {message.text}
      </div>
    );
  }
  if (message.deletedForAll) {
    return (
      <div className={cn("flex", mine ? "justify-end" : "justify-start")}>
        <div className="rounded-2xl bg-surface-2 px-3 py-2 text-sm italic text-muted">
          Сообщение удалено
        </div>
      </div>
    );
  }

  const onContext = (event: MouseEvent | TouchEvent) => {
    event.preventDefault();
    const point = "touches" in event ? event.touches[0] ?? event.changedTouches[0] : event;
    onLongPress(message, point.clientX, point.clientY);
  };

  return (
    <div className={cn("flex gap-2", mine ? "justify-end" : "justify-start")}>
      {!mine && isGroup && !grouped ? (
        <UserAvatar avatar={sender?.avatar ?? { kind: "gradient", hue: 200, initials: "?" }} size="sm" />
      ) : !mine && isGroup ? (
        <span className="w-9" />
      ) : null}
      <button
        type="button"
        onContextMenu={onContext}
        onTouchStart={(event) => {
          const timer = window.setTimeout(() => onContext(event), 380);
          const clear = () => window.clearTimeout(timer);
          event.currentTarget.addEventListener("touchend", clear, { once: true });
          event.currentTarget.addEventListener("touchmove", clear, { once: true });
        }}
        className={cn(
          "max-w-[82%] rounded-2xl px-3 py-2 text-left shadow-[var(--shadow-bubble)]",
          mine
            ? "rounded-br-md bg-outgoing text-white"
            : "rounded-bl-md bg-incoming text-fg",
          grouped && mine ? "rounded-tr-md" : null,
          grouped && !mine ? "rounded-tl-md" : null,
        )}
      >
        {!mine && isGroup && !grouped ? (
          <div className="mb-1 text-[11px] font-medium text-accent">{sender?.displayName}</div>
        ) : null}
        {message.forwarded ? (
          <div className={cn("mb-1 border-l-2 pl-2 text-[11px]", mine ? "border-white/40 text-white/70" : "border-accent text-muted")}>
            Переслано от {message.forwarded.fromName}
          </div>
        ) : null}
        {message.type === "voice" && message.voice ? (
          <VoicePlayer voice={message.voice} outgoing={mine} />
        ) : null}
        {message.type === "photo" && message.photo ? (
          <PhotoThumb payload={message.photo} onOpen={() => useTelechat.getState().openMedia(message.chatId, message.id)} />
        ) : null}
        {message.type === "video" && message.video ? (
          <VideoThumb payload={message.video} onOpen={() => useTelechat.getState().openMedia(message.chatId, message.id)} />
        ) : null}
        {message.text && message.type !== "voice" ? (
          <p className="whitespace-pre-wrap text-[15px] leading-snug">{message.text}</p>
        ) : null}
        <div className={cn("mt-1 flex items-center justify-end gap-1 text-[10px] tabular-nums", mine ? "text-white/65" : "text-muted")}>
          {formatTime(message.createdAt)}
          {mine ? (
            message.status === "read" ? (
              <CheckCheck className="size-3.5 text-white/90" />
            ) : (
              <Check className="size-3.5" />
            )
          ) : null}
        </div>
        <ReactionRow message={message} />
      </button>
    </div>
  );
}

function ReactionRow({ message }: { message: Message }) {
  const entries = (Object.entries(message.reactions) as Array<[ReactionId, string[]]>).filter(
    ([, ids]) => ids.length > 0,
  );
  if (!entries.length) return null;
  return (
    <div className="mt-1 flex flex-wrap gap-1">
      {entries.map(([id, users]) => (
        <span
          key={id}
          className="inline-flex items-center gap-1 rounded-full bg-black/15 px-1.5 py-0.5 text-[10px] font-medium"
        >
          <ReactionIcon id={id} className="size-3" />
          {users.length}
        </span>
      ))}
    </div>
  );
}

function PhotoThumb({
  payload,
  onOpen,
}: {
  payload: { mediaId: string; caption?: string };
  onOpen: () => void;
}) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    void getMedia(payload.mediaId).then(setSrc);
  }, [payload.mediaId]);
  return (
    <span
      role="button"
      tabIndex={0}
      onClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className="mb-1 block overflow-hidden rounded-xl"
    >
      {src ? (
        <img src={src} alt={payload.caption || "Фото"} className="max-h-64 w-full object-cover" />
      ) : (
        <span className="block h-36 w-56 bg-surface-2" />
      )}
    </span>
  );
}

function VideoThumb({
  payload,
  onOpen,
}: {
  payload: { mediaId: string; caption?: string; durationMs: number };
  onOpen: () => void;
}) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    void getMedia(payload.mediaId).then(setSrc);
  }, [payload.mediaId]);
  return (
    <span
      role="button"
      tabIndex={0}
      onClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className="relative mb-1 block overflow-hidden rounded-xl"
    >
      {src ? (
        <video src={src} className="max-h-64 w-full object-cover" muted />
      ) : (
        <span className="block h-36 w-56 bg-surface-2" />
      )}
        <span className="absolute inset-0 flex items-center justify-center">
        <span className="flex size-12 items-center justify-center rounded-full bg-black/45 text-white">
          <Play className="ml-0.5 size-5 fill-current" />
        </span>
      </span>
    </span>
  );
}

export function ReactionPicker({
  onPick,
}: {
  onPick: (id: ReactionId) => void;
}) {
  return (
    <div className="flex gap-1 rounded-full border border-border bg-surface p-1 shadow-[var(--shadow-float)]">
      {REACTIONS.map((item) => (
        <button
          key={item.id}
          type="button"
          aria-label={item.label}
          onClick={() => onPick(item.id)}
          className="tap flex size-10 items-center justify-center rounded-full hover:bg-surface-2"
        >
          <ReactionIcon id={item.id} className="size-5" />
        </button>
      ))}
    </div>
  );
}
