import { Delete } from "lucide-react";
import { cn } from "@/lib/utils";

export function NumericKeypad({
  onDigit,
  onBackspace,
  disabled,
}: {
  onDigit: (digit: string) => void;
  onBackspace: () => void;
  disabled?: boolean;
}) {
  const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "back"] as const;

  return (
    <div className="grid grid-cols-3 gap-2">
      {keys.map((key, index) => {
        if (key === "") return <span key={`empty-${index}`} />;
        if (key === "back") {
          return (
            <button
              key="back"
              type="button"
              disabled={disabled}
              onClick={onBackspace}
              aria-label="Стереть"
              className="tap flex h-14 items-center justify-center rounded-2xl bg-surface-2 text-fg transition-colors duration-150 hover:bg-surface disabled:opacity-40"
            >
              <Delete className="size-6" />
            </button>
          );
        }
        return (
          <button
            key={key}
            type="button"
            disabled={disabled}
            onClick={() => onDigit(key)}
            className={cn(
              "tap flex h-14 items-center justify-center rounded-2xl bg-surface-2 text-[22px] font-semibold tabular-nums",
              "transition-colors duration-150 hover:bg-surface active:bg-accent/20 disabled:opacity-40",
            )}
          >
            {key}
          </button>
        );
      })}
    </div>
  );
}

export function CodeSlots({
  value,
  length,
}: {
  value: string;
  length: number;
}) {
  return (
    <div className="flex justify-center gap-2">
      {Array.from({ length }).map((_, i) => (
        <span
          key={i}
          className={cn(
            "flex size-12 items-center justify-center rounded-2xl border bg-surface text-xl font-semibold tabular-nums transition-[border-color,box-shadow] duration-150",
            value.length === i
              ? "border-accent ring-2 ring-accent/40"
              : value[i]
                ? "border-accent/50"
                : "border-border",
          )}
        >
          {value[i] ?? ""}
        </span>
      ))}
    </div>
  );
}

export function PinDots({ value, length }: { value: string; length: number }) {
  return (
    <div className="flex justify-center gap-2.5">
      {Array.from({ length }).map((_, i) => (
        <span
          key={i}
          className={cn(
            "size-3.5 rounded-full border transition-colors duration-150",
            i < value.length ? "border-accent bg-accent" : "border-border-strong",
          )}
        />
      ))}
    </div>
  );
}
