import { AnimalFace } from "@/components/telechat/animal-avatar";
import type { AvatarSpec } from "@/lib/telechat/types";
import { cn } from "@/lib/utils";

export function UserAvatar({
  avatar,
  size = "md",
  online,
  className,
}: {
  avatar: AvatarSpec;
  size?: "sm" | "md" | "lg" | "xl";
  online?: boolean;
  className?: string;
}) {
  const dim =
    size === "sm"
      ? "size-9 text-[12px]"
      : size === "lg"
        ? "size-16 text-[22px]"
        : size === "xl"
          ? "size-24 text-[28px]"
          : "size-12 text-[15px]";
  const dot =
    size === "sm" ? "size-2" : size === "xl" ? "size-3.5" : "size-2.5";

  return (
    <div className={cn("relative shrink-0", dim, className)}>
      <div className="size-full overflow-hidden rounded-full ring-1 ring-border">
        {avatar.kind === "image" ? (
          <img src={avatar.src} alt="" className="size-full object-cover" />
        ) : avatar.kind === "animal" ? (
          <AnimalFace animal={avatar.animal} />
        ) : (
          <div
            className="flex size-full items-center justify-center font-semibold text-white"
            style={{
              background: `linear-gradient(145deg, hsl(${avatar.hue} 42% 46%), hsl(${(avatar.hue + 28) % 360} 38% 28%))`,
            }}
          >
            {avatar.initials}
          </div>
        )}
      </div>
      {online ? (
        <span
          className={cn(
            "absolute right-0 bottom-0 rounded-full bg-success ring-2 ring-bg",
            dot,
          )}
        />
      ) : null}
    </div>
  );
}
