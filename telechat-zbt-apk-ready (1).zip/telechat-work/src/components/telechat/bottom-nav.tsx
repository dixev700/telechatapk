import { MessageCircle, Settings, UserRound, Users } from "lucide-react";
import { t } from "@/lib/telechat/constants";
import type { TabId } from "@/lib/telechat/types";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

const TABS: Array<{ id: TabId; label: string; icon: typeof MessageCircle }> = [
  { id: "chats", label: t.chats, icon: MessageCircle },
  { id: "contacts", label: t.contacts, icon: Users },
  { id: "profile", label: t.you, icon: UserRound },
  { id: "settings", label: t.settings, icon: Settings },
];

export function BottomNav() {
  const tab = useTelechat((s) => s.ui.tab);
  const setTab = useTelechat((s) => s.setTab);
  const unread = useTelechat((s) =>
    s.chats.reduce((sum, c) => sum + (c.archived || c.deletedForMe ? 0 : c.unread), 0),
  );
  const activeIndex = Math.max(0, TABS.findIndex((item) => item.id === tab));

  return (
    <nav className="flex justify-center bg-transparent px-5 pt-3 pb-[max(1.45rem,calc(env(safe-area-inset-bottom)+0.95rem))]">
      <div className="relative grid w-full max-w-[440px] grid-cols-4 rounded-full bg-[#14181e] p-2.5 shadow-[0_18px_44px_rgb(0_0_0_/_48%)] ring-1 ring-white/8">
        <span
          aria-hidden
          className="pointer-events-none absolute top-2.5 bottom-2.5 rounded-full bg-white/14 shadow-[0_0_32px_rgb(255_255_255_/_20%)] transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{
            width: "calc((100% - 1.25rem) / 4)",
            left: "0.625rem",
            transform: `translateX(${activeIndex * 100}%)`,
          }}
        />
        {TABS.map((item) => {
          const active = tab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setTab(item.id);
                useTelechat.getState().openChat(null);
              }}
              className={cn(
                "relative z-10 flex min-h-[64px] flex-col items-center justify-center gap-1 rounded-full px-2 py-2.5 text-[12px] font-medium transition-[color,transform] duration-250 ease-[cubic-bezier(0.22,1,0.36,1)]",
                active ? "text-white" : "text-white/55 hover:text-white/80",
              )}
            >
              <span className="relative">
                <Icon
                  className="size-6 transition-[transform,filter] duration-250"
                  strokeWidth={active ? 2.4 : 1.7}
                  fill={active ? "currentColor" : "none"}
                />
                {item.id === "chats" && unread > 0 ? (
                  <span className="absolute -top-1.5 -right-2.5 min-w-4 rounded-full bg-white px-1 text-[9px] font-semibold text-black">
                    {unread > 99 ? "99+" : unread}
                  </span>
                ) : null}
              </span>
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
