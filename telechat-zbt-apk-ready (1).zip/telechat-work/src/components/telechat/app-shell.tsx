import { useEffect } from "react";
import { AuthFlow, PinLock, Splash } from "@/components/telechat/auth-flow";
import { BottomNav } from "@/components/telechat/bottom-nav";
import { ChatInfo } from "@/components/telechat/chat-info";
import { ChatView } from "@/components/telechat/chat-view";
import { ChatsList } from "@/components/telechat/chats-list";
import { ContactsView } from "@/components/telechat/contacts-view";
import { CreateDirectSheet, CreateGroupSheet, ForwardSheet } from "@/components/telechat/create-sheets";
import { MediaViewer } from "@/components/telechat/media-viewer";
import { ProfileView } from "@/components/telechat/profile-view";
import { SettingsView } from "@/components/telechat/settings-view";
import { ComingSoonSheet } from "@/components/telechat/sheet";
import { COMING_SOON } from "@/lib/telechat/constants";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function TelechatApp() {
  const hydrated = useTelechat((s) => s.hydrated);
  const authStep = useTelechat((s) => s.authStep);
  const locked = useTelechat((s) => Boolean(s.session?.locked && s.profile?.pin));
  const tab = useTelechat((s) => s.ui.tab);
  const activeChatId = useTelechat((s) => s.ui.activeChatId);
  const createMode = useTelechat((s) => s.ui.createMode);
  const comingSoon = useTelechat((s) => s.ui.comingSoon);
  const chatInfoOpen = useTelechat((s) => s.ui.chatInfoOpen);
  const fontSize = useTelechat((s) => s.profile?.fontSize ?? "medium");

  useEffect(() => {
    void useTelechat.getState().hydrate();
    const timer = window.setInterval(() => useTelechat.getState().tickPresence(), 20000);
    return () => window.clearInterval(timer);
  }, []);

  if (authStep !== "app") return <AuthFlow />;
  if (!hydrated) return <Splash />;
  if (locked) return <PinLock />;

  const chatOpen = Boolean(activeChatId);
  const sizeClass =
    fontSize === "small" ? "text-[14.5px]" : fontSize === "large" ? "text-[17px]" : "text-[16px]";

  return (
    <div className={cn("mx-auto flex h-dvh max-w-6xl bg-bg", sizeClass)}>
      <aside
        className={cn(
          "flex min-h-0 w-full flex-col border-border md:max-w-[380px] md:border-r",
          chatOpen ? "hidden md:flex" : "flex",
        )}
      >
        <div className="min-h-0 flex-1 view-fade" key={tab}>
          {tab === "chats" ? <ChatsList /> : null}
          {tab === "contacts" ? <ContactsView /> : null}
          {tab === "settings" ? <SettingsView /> : null}
          {tab === "profile" ? <ProfileView /> : null}
        </div>
        <BottomNav />
      </aside>

      <section className={cn("relative min-h-0 min-w-0 flex-1", chatOpen ? "flex" : "hidden md:flex")}>
        {activeChatId ? (
          <div className="relative min-h-0 w-full slide-in" key={activeChatId}>
            <ChatView
              chatId={activeChatId}
              onBack={() => useTelechat.getState().openChat(null)}
            />
            {chatInfoOpen ? (
              <ChatInfo
                chatId={activeChatId}
                onClose={() => useTelechat.getState().setChatInfoOpen(false)}
              />
            ) : null}
          </div>
        ) : (
          <EmptyPane />
        )}
      </section>

      {createMode === "direct" ? <CreateDirectSheet /> : null}
      {createMode === "group" ? <CreateGroupSheet /> : null}
      <ForwardSheet />
      <MediaViewer />
      {comingSoon ? (
        <ComingSoonSheet
          title={COMING_SOON[comingSoon].title}
          body={COMING_SOON[comingSoon].body}
          onClose={() => useTelechat.getState().setComingSoon(null)}
        />
      ) : null}
    </div>
  );
}

function EmptyPane() {
  return (
    <div className="app-wallpaper-ink hidden h-full w-full flex-col items-center justify-center px-8 text-center md:flex">
      <div className="max-w-sm">
        <h2 className="text-2xl font-semibold tracking-tight">Выберите чат</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Слева — переписки и группы. Напишите сообщение, запишите голос или отправьте кадр из галереи.
        </p>
      </div>
    </div>
  );
}
