import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Overlay({
  open,
  onClose,
  children,
  className,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  className?: string;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button
        type="button"
        aria-label="Закрыть"
        className="absolute inset-0 bg-overlay fade-in"
        onClick={onClose}
      />
      <div
        className={cn(
          "relative z-10 w-full max-w-lg scale-in rounded-t-3xl border border-border bg-surface p-4 shadow-[var(--shadow-float)] sm:rounded-3xl sm:p-5",
          className,
        )}
      >
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-border-strong sm:hidden" />
        {children}
      </div>
    </div>
  );
}

export function ComingSoonSheet({
  title,
  body,
  onClose,
}: {
  title: string;
  body: string;
  onClose: () => void;
}) {
  return (
    <Overlay open onClose={onClose}>
      <div className="px-2 pb-3 pt-1 text-center">
        <div className="mx-auto mb-4 flex size-14 items-center justify-center rounded-2xl bg-accent-soft">
          <svg viewBox="0 0 24 24" className="size-6 text-accent" aria-hidden="true">
            <path
              d="M12 3v3M12 18v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M3 12h3M18 12h3M4.9 19.1 7 17M17 7l2.1-2.1"
              stroke="currentColor"
              strokeWidth="1.7"
              strokeLinecap="round"
            />
            <circle cx="12" cy="12" r="3.2" fill="currentColor" />
          </svg>
        </div>
        <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
        <p className="mt-3 text-sm font-medium text-fg">Эта функция в разработке</p>
        <button
          type="button"
          onClick={onClose}
          className="tap mt-5 h-11 w-full rounded-2xl bg-accent text-sm font-semibold text-accent-fg"
        >
          Понятно
        </button>
      </div>
    </Overlay>
  );
}

export function ConfirmSheet({
  title,
  body,
  confirmLabel,
  danger,
  onConfirm,
  onClose,
}: {
  title: string;
  body: string;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Overlay open onClose={onClose}>
      <div className="px-1 pb-2">
        <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onClose}
            className="tap h-11 rounded-2xl bg-surface-2 text-sm font-medium"
          >
            Отмена
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={cn(
              "tap h-11 rounded-2xl text-sm font-semibold",
              danger ? "bg-danger text-white" : "bg-accent text-accent-fg",
            )}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </Overlay>
  );
}
