import type { ReactNode } from "react";
import type { AnimalId } from "@/lib/telechat/types";

const FACE: Record<AnimalId, { bg: string; draw: ReactNode }> = {
  fox: {
    bg: "#c56a32",
    draw: (
      <>
        <path d="M8 22 L16 8 L24 22 Z" fill="#e3894a" />
        <path d="M10 12 L16 22 L22 12" fill="#f3d2b0" />
        <circle cx="13.2" cy="16.5" r="1.1" fill="#1b140f" />
        <circle cx="18.8" cy="16.5" r="1.1" fill="#1b140f" />
        <path d="M15.2 19.4h1.6l.6 1.4h-2.8z" fill="#1b140f" />
      </>
    ),
  },
  cat: {
    bg: "#d8a35a",
    draw: (
      <>
        <ellipse cx="16" cy="18" rx="8" ry="7" fill="#f0c27a" />
        <path d="M8 16 L10 7 L14 14 Z" fill="#f0c27a" />
        <path d="M24 16 L22 7 L18 14 Z" fill="#f0c27a" />
        <circle cx="13" cy="17.5" r="1.15" fill="#1b140f" />
        <circle cx="19" cy="17.5" r="1.15" fill="#1b140f" />
        <path d="M16 20.2c1.4 0 2.2.8 2.2.8" stroke="#1b140f" strokeWidth="1" fill="none" strokeLinecap="round" />
      </>
    ),
  },
  owl: {
    bg: "#3d4c63",
    draw: (
      <>
        <ellipse cx="16" cy="18" rx="8.5" ry="8" fill="#6d7f98" />
        <circle cx="12.4" cy="16.6" r="3.4" fill="#f4efe4" />
        <circle cx="19.6" cy="16.6" r="3.4" fill="#f4efe4" />
        <circle cx="12.4" cy="16.8" r="1.4" fill="#1b140f" />
        <circle cx="19.6" cy="16.8" r="1.4" fill="#1b140f" />
        <path d="M16 20 l2 3 h-4z" fill="#e2a15a" />
      </>
    ),
  },
  bear: {
    bg: "#7a4c2e",
    draw: (
      <>
        <circle cx="10" cy="11" r="3.2" fill="#8b5a38" />
        <circle cx="22" cy="11" r="3.2" fill="#8b5a38" />
        <ellipse cx="16" cy="18" rx="8.5" ry="7.5" fill="#a36a42" />
        <ellipse cx="16" cy="20" rx="4.2" ry="3.2" fill="#e8c9a8" />
        <circle cx="13.1" cy="16.4" r="1.15" fill="#1b140f" />
        <circle cx="18.9" cy="16.4" r="1.15" fill="#1b140f" />
      </>
    ),
  },
  panda: {
    bg: "#ececec",
    draw: (
      <>
        <ellipse cx="16" cy="18" rx="8.2" ry="7.6" fill="#f7f7f7" />
        <circle cx="10.2" cy="11.4" r="3" fill="#1c1c1c" />
        <circle cx="21.8" cy="11.4" r="3" fill="#1c1c1c" />
        <ellipse cx="12.4" cy="16.8" rx="2.6" ry="2.3" fill="#1c1c1c" />
        <ellipse cx="19.6" cy="16.8" rx="2.6" ry="2.3" fill="#1c1c1c" />
        <circle cx="12.6" cy="16.8" r="0.85" fill="#f7f7f7" />
        <circle cx="19.8" cy="16.8" r="0.85" fill="#f7f7f7" />
        <ellipse cx="16" cy="20.6" rx="1.4" ry="1" fill="#1c1c1c" />
      </>
    ),
  },
  wolf: {
    bg: "#6d7786",
    draw: (
      <>
        <path d="M7 22 L16 7 L25 22 Z" fill="#8b96a6" />
        <path d="M12 16 L16 22 L20 16" fill="#d5dbe4" />
        <circle cx="13.4" cy="16.2" r="1.05" fill="#1b140f" />
        <circle cx="18.6" cy="16.2" r="1.05" fill="#1b140f" />
        <path d="M16 18.6l1.3 2.1h-2.6z" fill="#1b140f" />
      </>
    ),
  },
  rabbit: {
    bg: "#e7c3c9",
    draw: (
      <>
        <ellipse cx="12" cy="9" rx="2.2" ry="6.4" fill="#f3d4d9" />
        <ellipse cx="20" cy="9" rx="2.2" ry="6.4" fill="#f3d4d9" />
        <ellipse cx="16" cy="19" rx="7.4" ry="6.6" fill="#f7dde1" />
        <circle cx="13.3" cy="18.4" r="1.05" fill="#1b140f" />
        <circle cx="18.7" cy="18.4" r="1.05" fill="#1b140f" />
        <ellipse cx="16" cy="21.4" rx="1.2" ry="0.9" fill="#d98996" />
      </>
    ),
  },
  whale: {
    bg: "#3a6d8c",
    draw: (
      <>
        <ellipse cx="15" cy="17.5" rx="9" ry="6.2" fill="#5a97b8" />
        <path d="M23 17 l6 -4 v8z" fill="#5a97b8" />
        <circle cx="11.5" cy="16.4" r="1.15" fill="#0e1b24" />
        <circle cx="11.9" cy="16.1" r="0.35" fill="#f4f7fa" />
        <path d="M8 18.6c1.6 1.4 3.6 1.4 5.2 0" stroke="#0e1b24" strokeWidth="1" fill="none" />
      </>
    ),
  },
  bird: {
    bg: "#e0b84a",
    draw: (
      <>
        <ellipse cx="16" cy="18" rx="8" ry="6.5" fill="#f0c85c" />
        <circle cx="21" cy="13" r="4.4" fill="#f0c85c" />
        <circle cx="22.2" cy="12.4" r="1.05" fill="#1b140f" />
        <path d="M24.8 13.4l4 .8-4 1.6z" fill="#e07a32" />
        <path d="M8 18 l6 2 -6 2z" fill="#d9a32c" />
      </>
    ),
  },
  tiger: {
    bg: "#d98332",
    draw: (
      <>
        <ellipse cx="16" cy="18" rx="8.4" ry="7.4" fill="#e79a44" />
        <path d="M8 12 l3-5 3 6" fill="#e79a44" />
        <path d="M24 12 l-3-5 -3 6" fill="#e79a44" />
        <path d="M12 13 v8 M16 12 v10 M20 13 v8" stroke="#1b140f" strokeWidth="1.3" />
        <circle cx="13" cy="17.5" r="1.1" fill="#1b140f" />
        <circle cx="19" cy="17.5" r="1.1" fill="#1b140f" />
      </>
    ),
  },
  frog: {
    bg: "#5ea35a",
    draw: (
      <>
        <ellipse cx="16" cy="19" rx="9" ry="6.5" fill="#7bc16f" />
        <circle cx="11.5" cy="14" r="3.3" fill="#7bc16f" />
        <circle cx="20.5" cy="14" r="3.3" fill="#7bc16f" />
        <circle cx="11.5" cy="14" r="1.4" fill="#1b140f" />
        <circle cx="20.5" cy="14" r="1.4" fill="#1b140f" />
        <ellipse cx="16" cy="21.2" rx="2.4" ry="1.2" fill="#2a4a28" />
      </>
    ),
  },
  dog: {
    bg: "#c48a4a",
    draw: (
      <>
        <ellipse cx="16" cy="18.5" rx="8" ry="7" fill="#d9a05c" />
        <ellipse cx="8.6" cy="16" rx="2.4" ry="3.6" fill="#b4783c" />
        <ellipse cx="23.4" cy="16" rx="2.4" ry="3.6" fill="#b4783c" />
        <ellipse cx="16" cy="21" rx="3.4" ry="2.4" fill="#f0d3ae" />
        <circle cx="13.2" cy="17.2" r="1.1" fill="#1b140f" />
        <circle cx="18.8" cy="17.2" r="1.1" fill="#1b140f" />
      </>
    ),
  },
  deer: {
    bg: "#b07848",
    draw: (
      <>
        <path d="M10 10 l-2-6 M10 10 l2-5 M22 10 l2-6 M22 10 l-2-5" stroke="#d9b08a" strokeWidth="1.4" fill="none" />
        <ellipse cx="16" cy="18.4" rx="7.6" ry="7" fill="#c48a58" />
        <circle cx="13.3" cy="17.4" r="1.05" fill="#1b140f" />
        <circle cx="18.7" cy="17.4" r="1.05" fill="#1b140f" />
        <ellipse cx="16" cy="21.2" rx="1.5" ry="1.1" fill="#1b140f" />
      </>
    ),
  },
  penguin: {
    bg: "#2c3644",
    draw: (
      <>
        <ellipse cx="16" cy="18" rx="8" ry="8.4" fill="#3b4656" />
        <ellipse cx="16" cy="20" rx="5.4" ry="6" fill="#f4efe6" />
        <circle cx="13.2" cy="15.2" r="1.05" fill="#0e1116" />
        <circle cx="18.8" cy="15.2" r="1.05" fill="#0e1116" />
        <path d="M16 16.4l2.2 1.4h-4.4z" fill="#e28a3a" />
      </>
    ),
  },
  koala: {
    bg: "#9aa3ad",
    draw: (
      <>
        <circle cx="8.5" cy="13.5" r="4.4" fill="#b7c0c9" />
        <circle cx="23.5" cy="13.5" r="4.4" fill="#b7c0c9" />
        <ellipse cx="16" cy="18.5" rx="8" ry="7.2" fill="#c5ced6" />
        <ellipse cx="16" cy="20.6" rx="3.2" ry="2.4" fill="#e7edf2" />
        <circle cx="13.2" cy="17.2" r="1.1" fill="#1b140f" />
        <circle cx="18.8" cy="17.2" r="1.1" fill="#1b140f" />
      </>
    ),
  },
  otter: {
    bg: "#8a5a3c",
    draw: (
      <>
        <ellipse cx="16" cy="17.8" rx="8.4" ry="7.2" fill="#a66c48" />
        <ellipse cx="16" cy="20.4" rx="4" ry="2.8" fill="#e8c7a6" />
        <circle cx="12.8" cy="16.6" r="1.1" fill="#1b140f" />
        <circle cx="19.2" cy="16.6" r="1.1" fill="#1b140f" />
        <path d="M8 22c3 3 13 3 16 0" stroke="#a66c48" strokeWidth="3" fill="none" />
      </>
    ),
  },
};

export function AnimalFace({ animal }: { animal: AnimalId }) {
  const spec = FACE[animal];
  return (
    <svg viewBox="0 0 32 32" className="size-full" aria-hidden="true">
      <rect width="32" height="32" rx="16" fill={spec.bg} />
      {spec.draw}
    </svg>
  );
}
