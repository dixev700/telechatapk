-- TeleChat app schema (per-user rows keyed by Better Auth user_id text)

create table if not exists tc_profiles (
  user_id text primary key,
  email text not null default '',
  display_name text not null,
  username text not null unique,
  avatar_json text not null,
  bio text not null default '',
  pin text,
  theme text not null default 'dark',
  wallpaper text not null default 'ink',
  last_seen_privacy text not null default 'everyone',
  read_receipts boolean not null default true,
  notification_sound boolean not null default true,
  font_size text not null default 'medium',
  created_at bigint not null
);
create unique index if not exists tc_profiles_username_idx on tc_profiles (username);

create table if not exists tc_devices (
  id text not null,
  user_id text not null,
  name text not null,
  platform text not null,
  location text not null default '',
  last_active bigint not null,
  created_at bigint not null,
  primary key (id, user_id)
);
create index if not exists tc_devices_user_idx on tc_devices (user_id);

create table if not exists tc_chats (
  id text primary key,
  type text not null,
  title text not null,
  avatar_json text not null,
  created_by text not null,
  created_at bigint not null
);

create table if not exists tc_chat_members (
  chat_id text not null,
  user_id text not null,
  unread integer not null default 0,
  muted boolean not null default false,
  archived boolean not null default false,
  pinned boolean not null default false,
  deleted boolean not null default false,
  last_read_at bigint not null default 0,
  primary key (chat_id, user_id)
);
create index if not exists tc_chat_members_user_idx on tc_chat_members (user_id);

create table if not exists tc_messages (
  id text primary key,
  chat_id text not null,
  sender_id text not null,
  type text not null,
  body text not null default '',
  payload_json text not null default '{}',
  reply_to_id text,
  forwarded_json text,
  reactions_json text not null default '{}',
  deleted_for_all boolean not null default false,
  created_at bigint not null
);
create index if not exists tc_messages_chat_idx on tc_messages (chat_id, created_at);

create table if not exists tc_message_hidden (
  message_id text not null,
  user_id text not null,
  primary key (message_id, user_id)
);

create table if not exists tc_blocks (
  user_id text not null,
  blocked_id text not null,
  primary key (user_id, blocked_id)
);
